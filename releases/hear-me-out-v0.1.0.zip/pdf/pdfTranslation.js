// src/pdf/pdfTranslation.ts
var STORAGE_PREFIX = "pdfTranslation:";
var titleEl = getElement("title");
var sourceEl = getElement("source");
var contentEl = getElement("content");
void init();
async function init() {
  const id = new URLSearchParams(location.search).get("id");
  if (!id) {
    renderError("\u7F3A\u5C11 PDF \u7FFB\u8BD1\u7ED3\u679C\u7F16\u53F7\u3002");
    return;
  }
  const key = `${STORAGE_PREFIX}${id}`;
  const stored = await chrome.storage.local.get(key);
  const data = stored[key];
  if (!data) {
    renderError("\u6CA1\u6709\u627E\u5230\u8FD9\u4E2A PDF \u7FFB\u8BD1\u7ED3\u679C\u3002");
    return;
  }
  titleEl.textContent = data.title || "PDF \u7FFB\u8BD1";
  sourceEl.href = data.sourceUrl;
  sourceEl.textContent = "\u6253\u5F00\u539F\u59CB PDF";
  renderParagraphs(data.paragraphs);
}
function renderParagraphs(paragraphs) {
  contentEl.textContent = "";
  if (paragraphs.length === 0) {
    contentEl.append(createElement("p", "empty", "\u8FD9\u4E2A PDF \u6CA1\u6709\u53EF\u9009\u62E9\u7684\u6587\u672C\u3002\u626B\u63CF\u7248 PDF \u9700\u8981 OCR \u652F\u6301\u3002"));
    return;
  }
  for (const paragraph of paragraphs) {
    const article = document.createElement("article");
    article.className = "paragraph";
    article.append(
      createElement("p", "translation", paragraph.translation || paragraph.source),
      createElement("p", "source", paragraph.source)
    );
    contentEl.append(article);
  }
}
function renderError(message) {
  titleEl.textContent = "PDF \u7FFB\u8BD1\u4E0D\u53EF\u7528";
  sourceEl.removeAttribute("href");
  sourceEl.textContent = "";
  contentEl.textContent = "";
  contentEl.append(createElement("p", "empty", message));
}
function createElement(tagName, className, text) {
  const element = document.createElement(tagName);
  element.className = className;
  element.textContent = text;
  return element;
}
function getElement(id) {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Missing element #${id}`);
  return element;
}
//# sourceMappingURL=pdfTranslation.js.map
