// src/offscreen/offscreen.ts
var sessions = /* @__PURE__ */ new Map();
var SESSION_HEALTH_CHECK_MS = 2e3;
var MAX_SOCKET_BUFFERED_BYTES = 768 * 1024;
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "offscreen:start") {
    startSession(message.tabId, message.settings, message.streamId).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) }));
    return true;
  }
  if (message.type === "offscreen:stop") {
    void stopSession(message.tabId);
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === "offscreen:pause") {
    const session = sessions.get(message.tabId);
    if (session && !session.stopping) {
      session.paused = true;
      if (session.mockTimer) {
        window.clearInterval(session.mockTimer);
        delete session.mockTimer;
      }
      if (session.socket?.readyState === WebSocket.OPEN) {
        try {
          session.socket.send(JSON.stringify({ type: "session.stop" }));
        } catch {
        }
      }
    }
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === "offscreen:resume") {
    const session = sessions.get(message.tabId);
    if (session && !session.stopping) {
      session.paused = false;
      session.lastAudioFrameAt = Date.now();
      if (session.mode === "mock") {
        startMockSession(session);
      } else {
        const socket = ensureSocket(session);
        if (socket.readyState === WebSocket.OPEN) {
          try {
            socket.send(
              JSON.stringify({
                type: "session.start",
                targetLanguage: session.settings.targetLanguage,
                sampleRate: 16e3,
                format: "pcm16",
                asr: session.settings.asr,
                translation: session.settings.translation
              })
            );
          } catch {
          }
        }
      }
    }
    sendResponse({ ok: true });
    return false;
  }
  return false;
});
async function startSession(tabId, settings, streamId) {
  await stopSession(tabId);
  const session = {
    tabId,
    settings,
    mode: settings.backendUrl ? "websocket" : "mock",
    startedAt: Date.now(),
    ...streamId ? { streamId } : {}
  };
  sessions.set(tabId, session);
  if (settings.backendUrl) {
    await startWebSocketSession(session);
    return;
  }
  if (settings.mockWhenBackendMissing) {
    startMockSession(session);
    return;
  }
  throw new Error("\u672C\u673A\u7FFB\u8BD1\u670D\u52A1\u672A\u914D\u7F6E\uFF0C\u4E14\u6A21\u62DF\u5B57\u5E55\u5DF2\u5173\u95ED\u3002");
}
async function startWebSocketSession(session) {
  if (!session.streamId) throw new Error("Missing tab capture stream ID.");
  const stream = await captureTabAudio(session.streamId);
  const audioContext = new AudioContext({ sampleRate: 16e3 });
  await audioContext.audioWorklet.addModule(chrome.runtime.getURL("offscreen/audioWorkletProcessor.js"));
  const source = audioContext.createMediaStreamSource(stream);
  const worklet = new AudioWorkletNode(audioContext, "rvt-audio-worklet", {
    numberOfInputs: 1,
    numberOfOutputs: 1,
    outputChannelCount: [1],
    processorOptions: { targetSampleRate: 16e3 }
  });
  worklet.port.onmessage = (event) => {
    if (!sessions.has(session.tabId) || session.stopping || session.paused) return;
    session.lastAudioFrameAt = Date.now();
    const socket = ensureSocket(session);
    if (socket.readyState === WebSocket.OPEN && socket.bufferedAmount < MAX_SOCKET_BUFFERED_BYTES) {
      socket.send(event.data);
    }
  };
  source.connect(worklet);
  worklet.connect(audioContext.destination);
  session.stream = stream;
  session.audioContext = audioContext;
  session.source = source;
  session.worklet = worklet;
  ensureSocket(session);
  startSessionHealthCheck(session);
}
function startSessionHealthCheck(session) {
  if (session.healthTimer) window.clearInterval(session.healthTimer);
  session.healthTimer = window.setInterval(() => {
    if (!sessions.has(session.tabId) || session.stopping) return;
    if (session.audioContext?.state === "suspended") {
      void session.audioContext.resume().catch(() => void 0);
    }
    if (session.paused) return;
    const trackLive = session.stream?.getAudioTracks().some((track) => track.readyState === "live") ?? false;
    if (!trackLive) return;
    if (!session.socket || session.socket.readyState === WebSocket.CLOSED || session.socket.readyState === WebSocket.CLOSING) {
      ensureSocket(session);
    }
    if (session.socket?.readyState === WebSocket.OPEN && session.socket.bufferedAmount > MAX_SOCKET_BUFFERED_BYTES) {
      session.socket.close();
    }
  }, SESSION_HEALTH_CHECK_MS);
}
function ensureSocket(session) {
  if (session.socket && (session.socket.readyState === WebSocket.OPEN || session.socket.readyState === WebSocket.CONNECTING)) {
    return session.socket;
  }
  const socket = new WebSocket(session.settings.backendUrl);
  socket.binaryType = "arraybuffer";
  session.socket = socket;
  socket.addEventListener("open", () => {
    if (session.stopping || session.paused || session.socket !== socket) {
      socket.close();
      return;
    }
    socket.send(
      JSON.stringify({
        type: "session.start",
        targetLanguage: session.settings.targetLanguage,
        sampleRate: 16e3,
        format: "pcm16",
        asr: session.settings.asr,
        translation: session.settings.translation
      })
    );
  });
  socket.addEventListener("message", (event) => {
    const update = parseBackendCaption(event.data);
    if (update) void publishCaption(session.tabId, update);
  });
  socket.addEventListener("close", () => {
    if (session.socket === socket) delete session.socket;
  });
  socket.addEventListener("error", () => {
    if (session.stopping) return;
    void publishCaption(session.tabId, {
      id: `error-${Date.now()}`,
      sourceText: "\u672C\u673A\u670D\u52A1\u8FDE\u63A5\u5931\u8D25\u3002",
      translatedText: "\u672C\u673A\u670D\u52A1\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u786E\u8BA4\u672C\u673A\u7FFB\u8BD1\u670D\u52A1\u5DF2\u542F\u52A8\u3002\u6062\u590D\u64AD\u653E\u540E\u4F1A\u81EA\u52A8\u91CD\u8FDE\u3002",
      isFinal: true,
      startedAt: session.startedAt,
      receivedAt: Date.now()
    });
  });
  session.socket = socket;
  return socket;
}
function startMockSession(session) {
  if (session.mockTimer) {
    window.clearInterval(session.mockTimer);
    delete session.mockTimer;
  }
  const script = [
    ["The browser is capturing this tab audio in realtime.", "\u6D4F\u89C8\u5668\u6B63\u5728\u5B9E\u65F6\u91C7\u96C6\u5F53\u524D\u6807\u7B7E\u9875\u97F3\u9891\u3002"],
    ["Interim captions appear first and can be replaced quickly.", "\u4E34\u65F6\u5B57\u5E55\u4F1A\u5148\u51FA\u73B0\uFF0C\u5E76\u4E14\u53EF\u4EE5\u5FEB\u901F\u88AB\u4FEE\u6B63\u3002"],
    ["Final captions lock after a short pause in speech.", "\u8BF4\u8BDD\u77ED\u6682\u505C\u987F\u540E\uFF0C\u5B57\u5E55\u4F1A\u53D8\u6210\u786E\u8BA4\u7ED3\u679C\u3002"],
    ["Connect a streaming speech service to replace this demo feed.", "\u63A5\u5165\u6D41\u5F0F\u8BED\u97F3\u8BC6\u522B\u670D\u52A1\u540E\uFF0C\u5C31\u80FD\u66FF\u6362\u8FD9\u6761\u6A21\u62DF\u6D41\u3002"]
  ];
  let index = 0;
  let partial = 0;
  session.mockTimer = window.setInterval(() => {
    const [sourceText, translatedText] = script[index % script.length] ?? script[0];
    const words = sourceText.split(" ");
    partial = Math.min(words.length, partial + 2);
    const isFinal = partial >= words.length;
    const sourceChunk = words.slice(0, partial).join(" ");
    void publishCaption(session.tabId, {
      id: `mock-${index}`,
      sourceText: sourceChunk,
      translatedText: isFinal ? translatedText : translatedText.slice(0, Math.max(2, Math.round(translatedText.length * partial / words.length))),
      isFinal,
      startedAt: session.startedAt,
      receivedAt: Date.now()
    });
    if (isFinal) {
      index += 1;
      partial = 0;
    }
  }, 360);
}
function captureTabAudio(streamId) {
  return navigator.mediaDevices.getUserMedia({
    audio: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId,
        googDisableLocalEcho: false
      }
    },
    video: false
  });
}
async function stopSession(tabId) {
  const session = sessions.get(tabId);
  if (!session) return;
  session.stopping = true;
  if (session.mockTimer) window.clearInterval(session.mockTimer);
  if (session.healthTimer) window.clearInterval(session.healthTimer);
  session.socket?.close();
  session.worklet?.disconnect();
  session.source?.disconnect();
  session.stream?.getTracks().forEach((track) => track.stop());
  await session.audioContext?.close().catch(() => void 0);
  sessions.delete(tabId);
}
function parseBackendCaption(data) {
  if (typeof data !== "string") return null;
  try {
    const parsed = JSON.parse(data);
    if (parsed.status === "error") return null;
    const sourceText = parsed.sourceText ?? parsed.text ?? "";
    const translatedText = parsed.translatedText ?? parsed.translation ?? "";
    if (!sourceText && !translatedText) return null;
    if (looksLikeBackendErrorText(sourceText) || looksLikeBackendErrorText(translatedText)) return null;
    const caption = {
      id: parsed.id ?? `caption-${Date.now()}`,
      sourceText,
      translatedText,
      isFinal: parsed.isFinal ?? parsed.final ?? false,
      startedAt: parsed.startedAt ?? Date.now(),
      receivedAt: Date.now()
    };
    if (typeof parsed.revision === "number") caption.revision = parsed.revision;
    return caption;
  } catch {
    return null;
  }
}
function looksLikeBackendErrorText(text) {
  return /timeout waiting next packet|server[_\s-]?error|火山\s*asr\s*错误|backend connection failed|后端连接失败|"\s*error\s*"\s*:/i.test(
    text
  );
}
async function publishCaption(tabId, caption) {
  await chrome.runtime.sendMessage({ type: "caption:update", tabId, caption });
}
//# sourceMappingURL=offscreen.js.map
