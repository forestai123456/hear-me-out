// src/types.ts
var DEFAULT_SETTINGS = {
  schemaVersion: 7,
  enabled: true,
  targetLanguage: "zh-CN",
  backendUrl: "ws://localhost:8787/realtime",
  asr: {
    provider: "volcengine",
    appId: "",
    accessToken: "",
    apiKey: "",
    apiSecret: "",
    secretId: "",
    secretKey: "",
    appKey: "",
    resourceId: "volc.seedasr.sauc.duration",
    endpoint: "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_async",
    model: "doubao-seed-asr"
  },
  translation: {
    provider: "microsoft",
    protocol: "openai",
    apiKey: "",
    baseUrl: "",
    model: "",
    disableThinking: true
  },
  mockWhenBackendMissing: false,
  autoTranslatePages: false,
  selectionTranslationEnabled: false,
  showOriginal: false,
  showTranslation: true,
  subtitleStyle: "bold",
  floating: true
};

// src/background.ts
var OFFSCREEN_DOCUMENT_PATH = "offscreen/offscreen.html";
var PDF_TRANSLATION_STORAGE_PREFIX = "pdfTranslation:";
var runningTabs = /* @__PURE__ */ new Map();
chrome.runtime.onInstalled.addListener(async () => {
  await getSettings();
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then((response) => sendResponse(response)).catch((error) => {
    sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) });
  });
  return true;
});
chrome.tabs.onRemoved.addListener((tabId) => {
  runningTabs.delete(tabId);
  void chrome.runtime.sendMessage({ type: "offscreen:stop", tabId }).catch(() => void 0);
});
async function handleMessage(message, sender) {
  switch (message.type) {
    case "translator:start": {
      const tabId = message.tabId ?? sender.tab?.id ?? await getActiveTabId();
      const settings = await getSettings();
      const mode = await startTabCaptureSession(tabId, settings, true);
      return { ok: true, running: true, suspended: false, mode };
    }
    case "translator:stop": {
      const tabId = message.tabId ?? sender.tab?.id ?? await getActiveTabId();
      runningTabs.delete(tabId);
      await chrome.runtime.sendMessage({ type: "offscreen:stop", tabId }).catch(() => void 0);
      await chrome.tabs.sendMessage(tabId, { type: "caption:clear", tabId }, { frameId: 0 }).catch(() => void 0);
      await chrome.tabs.sendMessage(tabId, { type: "caption:state", running: false, mode: "mock" }, { frameId: 0 }).catch(() => void 0);
      return { ok: true, running: false };
    }
    case "translator:suspend": {
      const tabId = message.tabId ?? sender.tab?.id ?? await getActiveTabId();
      const status = runningTabs.get(tabId);
      if (!status) return { ok: true, running: false };
      runningTabs.set(tabId, { ...status, suspended: true });
      await chrome.runtime.sendMessage({ type: "offscreen:pause", tabId }).catch(() => void 0);
      await chrome.tabs.sendMessage(tabId, { type: "caption:clear", tabId }, { frameId: 0 }).catch(() => void 0);
      await chrome.tabs.sendMessage(tabId, { type: "caption:state", running: true, mode: status.mode }, { frameId: 0 }).catch(() => void 0);
      return { ok: true, running: true, suspended: true, mode: status.mode };
    }
    case "translator:resume": {
      const tabId = message.tabId ?? sender.tab?.id ?? await getActiveTabId();
      const status = runningTabs.get(tabId);
      if (!status) return { ok: true, running: false };
      await chrome.runtime.sendMessage({ type: "offscreen:resume", tabId }).catch(() => void 0);
      runningTabs.set(tabId, { ...status, suspended: false });
      await chrome.tabs.sendMessage(tabId, { type: "caption:state", running: true, mode: status.mode }, { frameId: 0 }).catch(() => void 0);
      return { ok: true, running: true, suspended: false, mode: status.mode };
    }
    case "translator:status": {
      const tabId = message.tabId ?? sender.tab?.id ?? await getActiveTabId();
      const status = runningTabs.get(tabId);
      return { ok: true, running: Boolean(status), suspended: Boolean(status?.suspended), mode: status?.mode ?? "mock" };
    }
    case "translator:settings:get": {
      return { ok: true, settings: await getSettings() };
    }
    case "translator:settings:set": {
      const previous = await getSettings();
      const next = mergeSettings(previous, message.settings);
      await chrome.storage.local.set({ settings: next });
      if (previous.autoTranslatePages && !next.autoTranslatePages) {
        void restoreAllPageTranslations();
      }
      return { ok: true, settings: next };
    }
    case "page:translate": {
      const tabId = message.tabId ?? sender.tab?.id ?? await getActiveTabId();
      const settings = await getSettings();
      return translatePageInTab(tabId, message.targetLanguage ?? settings.targetLanguage, settings);
    }
    case "page:restore": {
      const tabId = message.tabId ?? sender.tab?.id ?? await getActiveTabId();
      await ensureContentScriptReady(tabId);
      const response = await chrome.tabs.sendMessage(tabId, { type: "page:restore" }, { frameId: 0 });
      return response;
    }
    case "page:translate:batch": {
      const settings = await getSettings();
      const translations = await translateBatch(message.texts, message.targetLanguage, settings);
      return { ok: true, translations };
    }
    case "caption:update": {
      const status = runningTabs.get(message.tabId);
      if (!status || status.suspended) return { ok: true };
      await chrome.tabs.sendMessage(message.tabId, message, { frameId: 0 }).catch(() => void 0);
      return { ok: true };
    }
    default:
      return { ok: false, error: `Unhandled message: ${message.type}` };
  }
}
async function startTabCaptureSession(tabId, settings, clearCaption) {
  const mode = settings.backendUrl ? "websocket" : "mock";
  await ensureContentScriptReady(tabId);
  await ensureOffscreenDocument();
  await chrome.runtime.sendMessage({ type: "offscreen:stop", tabId }).catch(() => void 0);
  await wait(150);
  const streamId = settings.backendUrl ? await getMediaStreamId(tabId) : void 0;
  const startMessage = {
    type: "offscreen:start",
    tabId,
    settings,
    ...streamId ? { streamId } : {}
  };
  await chrome.runtime.sendMessage(startMessage);
  runningTabs.set(tabId, { mode, suspended: false });
  if (clearCaption) {
    await chrome.tabs.sendMessage(tabId, { type: "caption:clear", tabId }, { frameId: 0 }).catch(() => void 0);
  }
  await chrome.tabs.sendMessage(tabId, { type: "caption:state", running: true, mode }, { frameId: 0 }).catch(() => void 0);
  return mode;
}
async function translatePageInTab(tabId, targetLanguage, settings) {
  const tab = await chrome.tabs.get(tabId);
  if (isPdfTab(tab)) {
    const result = await translatePdf(tab, targetLanguage, settings);
    return { ok: true, translated: result.paragraphs.length, pdfTranslationUrl: result.url };
  }
  await ensureContentScriptReady(tabId);
  const response = await chrome.tabs.sendMessage(tabId, {
    type: "page:translate",
    targetLanguage
  }, { frameId: 0 });
  return response;
}
async function restoreAllPageTranslations() {
  const tabs = await chrome.tabs.query({});
  await Promise.all(
    tabs.map(async (tab) => {
      if (!tab.id || !isAutoPageTranslationUrl(tab.url)) return;
      await chrome.tabs.sendMessage(tab.id, { type: "page:restore" }, { frameId: 0 }).catch(() => void 0);
    })
  );
}
async function getSettings() {
  const localStored = await chrome.storage.local.get("settings");
  if (localStored.settings && localStored.settings.schemaVersion === DEFAULT_SETTINGS.schemaVersion) {
    return mergeSettings(DEFAULT_SETTINGS, localStored.settings);
  }
  const syncStored = await chrome.storage.sync.get("settings").catch(() => ({ settings: void 0 }));
  const raw = localStored.settings ?? syncStored.settings;
  const rawSchemaVersion = typeof raw?.schemaVersion === "number" ? raw.schemaVersion : 0;
  const settings = mergeSettings(DEFAULT_SETTINGS, raw);
  const migrated = {
    ...settings,
    schemaVersion: DEFAULT_SETTINGS.schemaVersion,
    backendUrl: settings.backendUrl || DEFAULT_SETTINGS.backendUrl,
    mockWhenBackendMissing: false
  };
  if (rawSchemaVersion < 6 && migrated.showOriginal && migrated.showTranslation) {
    migrated.showOriginal = false;
    migrated.showTranslation = true;
  }
  await chrome.storage.local.set({ settings: migrated });
  await chrome.storage.sync.remove("settings").catch(() => {
  });
  return migrated;
}
function mergeSettings(base, patch) {
  const next = {
    ...DEFAULT_SETTINGS,
    ...base,
    ...patch ?? {}
  };
  const patchAsr = patch?.asr ?? {};
  const patchTranslation = patch?.translation ?? {};
  return {
    ...next,
    schemaVersion: DEFAULT_SETTINGS.schemaVersion,
    backendUrl: next.backendUrl || DEFAULT_SETTINGS.backendUrl,
    asr: {
      ...DEFAULT_SETTINGS.asr,
      ...base.asr ?? {},
      ...patchAsr
    },
    translation: {
      ...DEFAULT_SETTINGS.translation,
      ...base.translation ?? {},
      ...patchTranslation
    }
  };
}
async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab found.");
  return tab.id;
}
async function ensureContentScriptReady(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "caption:state", running: false, mode: "mock" }, { frameId: 0 });
  } catch {
    await chrome.scripting?.executeScript?.({
      target: { tabId, allFrames: true },
      files: ["content/contentScript.js"]
    });
  }
}
async function ensureOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });
  if (contexts.length > 0) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "Capture the active tab audio and stream PCM frames to a realtime ASR backend."
  });
}
function getMediaStreamId(tabId) {
  return new Promise((resolve, reject) => {
    chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (streamId) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      if (!streamId) {
        reject(new Error("Chrome did not return a tab capture stream ID."));
        return;
      }
      resolve(streamId);
    });
  });
}
var microsoftToken = null;
var microsoftTokenExpiresAt = 0;
async function getMicrosoftToken() {
  if (microsoftToken && Date.now() < microsoftTokenExpiresAt) return microsoftToken;
  const response = await fetch("https://edge.microsoft.com/translate/auth");
  if (!response.ok) throw new Error(`Microsoft translate auth failed: ${response.status}`);
  microsoftToken = await response.text();
  microsoftTokenExpiresAt = Date.now() + 8 * 60 * 1e3;
  return microsoftToken;
}
async function translateWithMicrosoft(texts, targetLanguage) {
  if (texts.length === 0) return [];
  const token = await getMicrosoftToken();
  const response = await fetch(
    `https://api-edge.cognitive.microsofttranslator.com/translate?from=&to=${encodeURIComponent(targetLanguage)}&api-version=3.0&includeSentenceLength=true&textType=plain`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(texts.map((text) => ({ Text: text })))
    }
  );
  if (!response.ok) throw new Error(`Microsoft translation failed: ${response.status}`);
  const result = await response.json();
  return texts.map((_, i) => result?.[i]?.translations?.[0]?.text ?? "");
}
async function translateBatch(texts, targetLanguage, settings) {
  const translation = settings.translation;
  const hasAiKey = translation?.apiKey?.trim() && translation?.provider && translation.provider !== "microsoft";
  if (!hasAiKey) {
    return translateWithMicrosoft(texts, targetLanguage);
  }
  try {
    const endpoint = toTranslateEndpoint(settings.backendUrl || DEFAULT_SETTINGS.backendUrl);
    const body = { texts, targetLanguage, translation };
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!response.ok) throw new Error(await readBackendError(response, `\u540E\u7AEF\u8BF7\u6C42\u5931\u8D25\uFF1A${response.status}`));
    const result = await response.json();
    return result.translations ?? texts.map(() => "");
  } catch {
    return translateWithMicrosoft(texts, targetLanguage);
  }
}
async function translatePdf(tab, targetLanguage, settings) {
  if (!tab.url) throw new Error("\u5F53\u524D\u6807\u7B7E\u9875\u6CA1\u6709\u627E\u5230 PDF \u5730\u5740\u3002");
  const endpoint = toBackendEndpoint(settings.backendUrl || DEFAULT_SETTINGS.backendUrl, "/translate-pdf");
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      url: tab.url,
      title: tab.title || "PDF \u7FFB\u8BD1",
      targetLanguage,
      translation: settings.translation
    })
  });
  if (!response.ok) throw new Error(await readBackendError(response, `PDF \u7FFB\u8BD1\u540E\u7AEF\u8BF7\u6C42\u5931\u8D25\uFF1A${response.status}`));
  const result = await response.json();
  if (!result.ok) throw new Error(result.error || "PDF \u7FFB\u8BD1\u5931\u8D25\u3002");
  const paragraphs = (result.paragraphs ?? []).map((paragraph) => ({
    source: String(paragraph.source ?? ""),
    translation: String(paragraph.translation ?? "")
  })).filter((paragraph) => paragraph.source || paragraph.translation);
  if (paragraphs.length === 0) throw new Error("\u8FD9\u4E2A PDF \u6CA1\u6709\u53EF\u9009\u62E9\u7684\u6587\u672C\u3002\u626B\u63CF\u7248 PDF \u9700\u8981 OCR \u652F\u6301\u3002");
  const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  await chrome.storage.local.set({
    [`${PDF_TRANSLATION_STORAGE_PREFIX}${id}`]: {
      title: result.title || tab.title || "PDF \u7FFB\u8BD1",
      sourceUrl: result.sourceUrl || tab.url,
      createdAt: Date.now(),
      paragraphs
    }
  });
  const url = chrome.runtime.getURL(`pdf/pdfTranslation.html?id=${encodeURIComponent(id)}`);
  await chrome.tabs.create({ url, active: true });
  return { url, paragraphs };
}
async function readBackendError(response, fallback) {
  try {
    const result = await response.clone().json();
    if (result.error) return result.error;
  } catch {
  }
  return fallback;
}
function toTranslateEndpoint(backendUrl) {
  return toBackendEndpoint(backendUrl, "/translate");
}
function toBackendEndpoint(backendUrl, pathname) {
  const url = new URL(backendUrl);
  url.protocol = url.protocol === "wss:" ? "https:" : "http:";
  url.pathname = pathname;
  url.search = "";
  url.hash = "";
  return url.toString();
}
function isPdfTab(tab) {
  const url = tab.url || "";
  if (!url) return false;
  try {
    const parsed = new URL(url);
    if (parsed.protocol === "file:" && parsed.pathname.toLowerCase().endsWith(".pdf")) return true;
    if (parsed.pathname.toLowerCase().endsWith(".pdf")) return true;
    return /\.pdf(?:[?#]|$)/i.test(url);
  } catch {
    return /\.pdf(?:[?#]|$)/i.test(url);
  }
}
function isAutoPageTranslationUrl(url) {
  if (!url) return false;
  if (/\.pdf(?:[?#]|$)/i.test(url)) return false;
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:" && parsed.protocol !== "file:") return false;
    if (parsed.pathname.toLowerCase().endsWith(".pdf")) return false;
    return true;
  } catch {
    return false;
  }
}
function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
//# sourceMappingURL=background.js.map
