// src/content/contentScript.ts
var ROOT_ID = "rvt-subtitle-root";
var SELECTION_ROOT_ID = "rvt-selection-translation-root";
var NATIVE_CUE_STYLE_ID = "rvt-native-cue-style";
var PAGE_TRANSLATION_BATCH_SIZE = 20;
var PAGE_TRANSLATION_CONCURRENCY = 4;
var PAGE_TRANSLATION_MAX_NODES = 1500;
var PAGE_TRANSLATION_MAX_NODE_CHARS = 1800;
var DYNAMIC_PAGE_TRANSLATION_DELAY_MS = 800;
var TRANSLATED_NODE_HISTORY_LIMIT = 8e3;
var STABLE_CAPTION_MAX_CHARS = 24;
var STABLE_CAPTION_MIN_CHARS = 6;
var STABLE_CAPTION_FAST_COMMIT_MS = 650;
var STABLE_CAPTION_FALLBACK_COMMIT_MS = 2400;
var CAPTION_STALE_MS = 12e3;
var VIDEO_RESUME_GRACE_MS = 2800;
var VIDEO_RESUME_RESTART_THROTTLE_MS = 8e3;
var VIDEO_RESUME_FORCE_RESTART_THROTTLE_MS = 1500;
var VIDEO_RESUME_FORCE_RESTART_DELAY_MS = 350;
var SELECTION_TRANSLATION_MAX_CHARS = 1200;
var rvtWindow = window;
var IS_TOP_FRAME = window.top === window;
try {
  rvtWindow.__rvtContentScriptCleanup?.();
} catch {
}
document.getElementById(ROOT_ID)?.remove();
document.getElementById(SELECTION_ROOT_ID)?.remove();
var host = null;
var root = null;
var statusEl = null;
var sourceEl = null;
var translationEl = null;
var selectionHost = null;
var selectionRoot = null;
var selectionPreviewEl = null;
var selectionResultEl = null;
var selectionButton = null;
var selectionCloseButton = null;
var positionTimer = null;
var captionExpiryTimer = null;
var selectionCheckTimer = null;
var translatedTextNodes = [];
var nativeCaptionTrack = null;
var nativeCaptionVideo = null;
var activeCaptionVideo = null;
var lastCaption = null;
var lastStableTranslation = null;
var lastCaptionRevision = 0;
var committedCaptionLines = [];
var committedCaptionSourceKeys = [];
var pendingStableCaption = null;
var stableCaptionTimer = null;
var autoPageTranslationEnabled = false;
var autoPageTranslationTargetLanguage = "zh-CN";
var selectionTranslationEnabled = false;
var selectionTranslationTargetLanguage = "zh-CN";
var subtitleStyle = "bold";
var showOriginal = false;
var showTranslation = true;
var autoPageTranslationTimer = null;
var autoTriggeredTranslateRunning = false;
var pageTranslationObserver = null;
var observedPageUrl = location.href;
var activePageTranslationRunId = 0;
var autoPageTranslationWatchersInstalled = false;
var selectionTranslationWatchersInstalled = false;
var videoResumeWatchdogInstalled = false;
var videoResumeTimer = null;
var lastVideoResumeRestartAt = 0;
var videoPauseObserved = false;
var pendingVideoResumeForceRestart = false;
var translatorSuspendedByVideoPause = false;
var videoPauseSuspendInFlight = false;
var videoResumeInFlight = false;
var extensionContextInvalidated = false;
var originalPushState = null;
var originalReplaceState = null;
var selectedTextForTranslation = "";
var selectionTranslationRequestId = 0;
rvtWindow.__rvtContentScriptCleanup = cleanupContentScript;
void initAutoPageTranslation();
if (IS_TOP_FRAME) installSelectionTranslationWatchers();
if (IS_TOP_FRAME) installVideoResumeWatchdog();
window.addEventListener("unhandledrejection", handleUnhandledRejection);
if (isExtensionRuntimeAvailable()) {
  chrome.runtime.onMessage.addListener(handleRuntimeMessage);
}
function handleRuntimeMessage(message, _sender, sendResponse) {
  if (!isExtensionRuntimeAvailable()) return false;
  if (message.type === "caption:update") {
    if (IS_TOP_FRAME) renderCaption(message.caption);
  }
  if (message.type === "caption:clear") {
    if (IS_TOP_FRAME) clearCaptionDisplay();
  }
  if (message.type === "caption:state") {
    if (!IS_TOP_FRAME) return false;
    if (message.running) {
      ensureOverlay();
      setStatus(true, message.mode);
    } else if (host) {
      translatorSuspendedByVideoPause = false;
      clearCaptionDisplay();
    }
  }
  if (message.type === "page:translate") {
    const runId = ++activePageTranslationRunId;
    sendResponse({ ok: true, translated: 0, inProgress: true, runId });
    void translatePage(message.targetLanguage ?? "zh-CN").then((translated) => {
      if (runId !== activePageTranslationRunId) return;
      void chrome.runtime.sendMessage({
        type: "page:translate:done",
        runId,
        translated
      }).catch(() => void 0);
    }).catch((error) => {
      if (runId !== activePageTranslationRunId) return;
      void chrome.runtime.sendMessage({
        type: "page:translate:done",
        runId,
        translated: 0,
        error: error instanceof Error ? error.message : String(error)
      }).catch(() => void 0);
    });
    return false;
  }
  if (message.type === "page:restore") {
    const restored = restorePage();
    sendResponse({ ok: true, restored });
  }
  return false;
}
async function initAutoPageTranslation() {
  if (!isExtensionRuntimeAvailable()) return;
  installAutoPageTranslationWatchers();
  const response = await sendRuntimeMessageSafe({ type: "translator:settings:get" });
  if (!response?.ok || !response.settings) {
    console.warn("[hear-me-out] settings fetch failed, applying defaults");
    updateSettingsState({});
    return;
  }
  console.log("[hear-me-out] init settings:", JSON.stringify({
    autoTranslatePages: response.settings.autoTranslatePages,
    selectionTranslationEnabled: response.settings.selectionTranslationEnabled
  }));
  updateSettingsState(response.settings);
}
function installAutoPageTranslationWatchers() {
  if (autoPageTranslationWatchersInstalled) return;
  if (!isExtensionRuntimeAvailable()) return;
  autoPageTranslationWatchersInstalled = true;
  chrome.storage.onChanged.addListener(handleStorageChanged);
  originalPushState = history.pushState;
  history.pushState = function pushState(...args) {
    const result = originalPushState?.apply(this, args) ?? void 0;
    handlePageUrlMaybeChanged();
    return result;
  };
  originalReplaceState = history.replaceState;
  history.replaceState = function replaceState(...args) {
    const result = originalReplaceState?.apply(this, args) ?? void 0;
    handlePageUrlMaybeChanged();
    return result;
  };
  window.addEventListener("popstate", handlePageUrlMaybeChanged);
  window.addEventListener("hashchange", handlePageUrlMaybeChanged);
  window.addEventListener("pageshow", handleAutoPageShow);
}
function handleStorageChanged(changes, areaName) {
  if (areaName !== "local" && areaName !== "sync" || !changes.settings?.newValue) return;
  const newSettings = changes.settings.newValue;
  console.log("[hear-me-out] storage changed:", JSON.stringify({
    autoTranslatePages: newSettings.autoTranslatePages,
    selectionTranslationEnabled: newSettings.selectionTranslationEnabled
  }));
  updateSettingsState(newSettings);
}
function updateSettingsState(settings) {
  updateAutoPageTranslationState(Boolean(settings.autoTranslatePages), settings.targetLanguage ?? "zh-CN");
  updateSelectionTranslationState(settings.selectionTranslationEnabled !== false, settings.targetLanguage ?? "zh-CN");
  updateSubtitleStyle(settings.subtitleStyle);
  updateSubtitleDisplayMode(settings);
}
function updateSelectionTranslationState(enabled, targetLanguage) {
  selectionTranslationEnabled = enabled;
  selectionTranslationTargetLanguage = targetLanguage || "zh-CN";
  if (enabled) {
    installSelectionTranslationWatchers();
    scheduleSelectionTranslatorCheck(120);
    return;
  }
  hideSelectionTranslator();
}
function updateSubtitleStyle(nextStyle) {
  subtitleStyle = nextStyle ?? "bold";
  if (root) root.dataset.style = subtitleStyle;
}
function updateSubtitleDisplayMode(settings) {
  showOriginal = Boolean(settings.showOriginal);
  showTranslation = settings.showTranslation !== false;
  if (root) root.dataset.mode = showOriginal && showTranslation ? "bilingual" : "translation";
  renderCommittedCaptionLines();
}
function handleAutoPageShow() {
  scheduleAutoPageTranslation(500);
}
function updateAutoPageTranslationState(enabled, targetLanguage) {
  autoPageTranslationEnabled = enabled;
  autoPageTranslationTargetLanguage = targetLanguage || "zh-CN";
  if (enabled) {
    startPageTranslationObserver();
    scheduleAutoPageTranslation(700);
    return;
  }
  stopPageTranslationObserver();
  if (autoPageTranslationTimer !== null) {
    window.clearTimeout(autoPageTranslationTimer);
    autoPageTranslationTimer = null;
  }
  activePageTranslationRunId += 1;
  restorePage();
}
function handlePageUrlMaybeChanged() {
  if (!isExtensionRuntimeAvailable()) return;
  window.setTimeout(() => {
    if (!isExtensionRuntimeAvailable()) return;
    if (observedPageUrl === location.href) return;
    observedPageUrl = location.href;
    scheduleAutoPageTranslation(900);
  }, 0);
}
function scheduleAutoPageTranslation(delayMs) {
  if (!isExtensionRuntimeAvailable()) return;
  if (!autoPageTranslationEnabled) return;
  if (autoPageTranslationTimer !== null) window.clearTimeout(autoPageTranslationTimer);
  autoPageTranslationTimer = window.setTimeout(() => {
    autoPageTranslationTimer = null;
    if (!autoPageTranslationEnabled) return;
    autoTriggeredTranslateRunning = true;
    void translatePage(autoPageTranslationTargetLanguage).catch(() => void 0).finally(() => {
      autoTriggeredTranslateRunning = false;
    });
  }, delayMs);
}
function startPageTranslationObserver() {
  if (pageTranslationObserver || !document.body) return;
  pageTranslationObserver = new MutationObserver((mutations) => {
    if (!autoPageTranslationEnabled || pageTranslationObserverSuspended) {
      pageTranslationObserver?.takeRecords();
      return;
    }
    if (!mutations.some(containsNewTranslatableText)) return;
    scheduleAutoPageTranslation(DYNAMIC_PAGE_TRANSLATION_DELAY_MS);
  });
  pageTranslationObserver.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
}
function stopPageTranslationObserver() {
  pageTranslationObserver?.disconnect();
  pageTranslationObserver = null;
}
var pageTranslationObserverSuspended = false;
function pausePageTranslationObserver() {
  if (!pageTranslationObserver) return;
  pageTranslationObserverSuspended = true;
  pageTranslationObserver.takeRecords();
}
function resumePageTranslationObserver() {
  pageTranslationObserverSuspended = false;
}
function containsNewTranslatableText(mutation) {
  if (mutation.type === "characterData") {
    return isTranslatableTextNode(mutation.target);
  }
  for (const node of mutation.addedNodes) {
    if (isTranslatableTextNode(node)) return true;
    if (node instanceof Element && elementContainsTranslatableText(node)) return true;
  }
  return false;
}
function elementContainsTranslatableText(element) {
  if (shouldSkipTranslationElement(element)) return false;
  const text = (element.textContent ?? "").trim();
  return text.length > 1;
}
function isTranslatableTextNode(node) {
  if (node.nodeType !== Node.TEXT_NODE) return false;
  const text = node.nodeValue ?? "";
  if (text.trim().length < 2) return false;
  const parent = node.parentElement;
  return Boolean(parent && !shouldSkipTranslationElement(parent));
}
function installSelectionTranslationWatchers() {
  if (selectionTranslationWatchersInstalled) return;
  if (!isExtensionRuntimeAvailable()) return;
  selectionTranslationWatchersInstalled = true;
  document.addEventListener("selectionchange", handleSelectionChange);
  document.addEventListener("mouseup", handleSelectionGestureComplete, true);
  document.addEventListener("keyup", handleSelectionGestureComplete, true);
  document.addEventListener("mousedown", handleSelectionOutsideMouseDown, true);
  window.addEventListener("scroll", handleSelectionViewportChanged, true);
  window.addEventListener("resize", handleSelectionViewportChanged);
}
function handleSelectionChange() {
  scheduleSelectionTranslatorCheck(120);
}
function handleSelectionGestureComplete(event) {
  if (!selectionTranslationEnabled) return;
  if (isSelectionTranslatorEvent(event)) return;
  scheduleSelectionTranslatorCheck(70);
}
function handleSelectionOutsideMouseDown(event) {
  if (!selectionHost || selectionHost.dataset.visible !== "true") return;
  if (isSelectionTranslatorEvent(event)) return;
  hideSelectionTranslator();
}
function handleSelectionViewportChanged() {
  if (!selectionHost || selectionHost.dataset.visible !== "true") return;
  const info = getCurrentSelectionInfo();
  if (!info || info.text !== selectedTextForTranslation) {
    hideSelectionTranslator();
    return;
  }
  positionSelectionTranslator(info.rect);
}
function scheduleSelectionTranslatorCheck(delayMs) {
  if (!selectionTranslationEnabled || !isExtensionRuntimeAvailable()) return;
  if (selectionCheckTimer !== null) window.clearTimeout(selectionCheckTimer);
  selectionCheckTimer = window.setTimeout(() => {
    selectionCheckTimer = null;
    showTranslatorForCurrentSelection();
  }, delayMs);
}
function showTranslatorForCurrentSelection() {
  if (!selectionTranslationEnabled || !isExtensionRuntimeAvailable()) {
    hideSelectionTranslator();
    return;
  }
  const info = getCurrentSelectionInfo();
  if (!info) {
    hideSelectionTranslator();
    return;
  }
  ensureSelectionTranslator();
  if (!selectionHost || !selectionRoot || !selectionPreviewEl || !selectionResultEl || !selectionButton) return;
  selectedTextForTranslation = info.text;
  selectionTranslationRequestId += 1;
  selectionPreviewEl.textContent = compactSelectionPreview(info.text);
  selectionResultEl.textContent = "";
  selectionRoot.dataset.state = "ready";
  selectionHost.dataset.visible = "true";
  selectionButton.disabled = false;
  selectionButton.textContent = "\u7FFB\u8BD1";
  positionSelectionTranslator(info.rect);
}
function getCurrentSelectionInfo() {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0 || selection.isCollapsed) return null;
  const text = normalizeSelectionText(selection.toString());
  if (!text || text.length > SELECTION_TRANSLATION_MAX_CHARS) return null;
  const range = selection.getRangeAt(0);
  const container = getSelectionContainerElement(range);
  if (!container || shouldSkipSelectionElement(container)) return null;
  const rect = getSelectionRangeRect(range);
  if (!rect) return null;
  return { text, rect };
}
function normalizeSelectionText(text) {
  return text.replace(/\s+/g, " ").trim();
}
function compactSelectionPreview(text) {
  const normalized = normalizeSelectionText(text);
  if (normalized.length <= 80) return normalized;
  return `${normalized.slice(0, 78)}...`;
}
function getSelectionContainerElement(range) {
  const container = range.commonAncestorContainer;
  if (container instanceof Element) return container;
  return container.parentElement;
}
function getSelectionRangeRect(range) {
  const rects = Array.from(range.getClientRects()).filter((rect2) => rect2.width > 0 && rect2.height > 0);
  if (rects.length > 0) return rects[rects.length - 1] ?? null;
  const rect = range.getBoundingClientRect();
  if (rect.width > 0 && rect.height > 0) return rect;
  return null;
}
function shouldSkipSelectionElement(element) {
  if (element.closest(`#${ROOT_ID}, #${SELECTION_ROOT_ID}`)) return true;
  return shouldSkipTranslationElement(element);
}
function ensureSelectionTranslator() {
  if (selectionHost && document.documentElement.contains(selectionHost)) return;
  selectionHost = document.createElement("div");
  selectionHost.id = SELECTION_ROOT_ID;
  selectionHost.dataset.visible = "false";
  const shadow = selectionHost.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = SELECTION_TRANSLATOR_STYLE;
  selectionRoot = document.createElement("section");
  selectionRoot.className = "rvt-selection-panel";
  selectionRoot.dataset.state = "ready";
  const header = document.createElement("div");
  header.className = "rvt-selection-header";
  selectionButton = document.createElement("button");
  selectionButton.type = "button";
  selectionButton.className = "rvt-selection-action";
  selectionButton.textContent = "\u7FFB\u8BD1";
  selectionButton.addEventListener("mousedown", (event) => event.preventDefault());
  selectionButton.addEventListener("click", () => {
    void translateSelectedText();
  });
  selectionCloseButton = document.createElement("button");
  selectionCloseButton.type = "button";
  selectionCloseButton.className = "rvt-selection-close";
  selectionCloseButton.textContent = "\xD7";
  selectionCloseButton.title = "\u5173\u95ED";
  selectionCloseButton.addEventListener("mousedown", (event) => event.preventDefault());
  selectionCloseButton.addEventListener("click", hideSelectionTranslator);
  header.append(selectionButton, selectionCloseButton);
  selectionPreviewEl = document.createElement("p");
  selectionPreviewEl.className = "rvt-selection-source";
  selectionResultEl = document.createElement("p");
  selectionResultEl.className = "rvt-selection-result";
  selectionRoot.append(header, selectionPreviewEl, selectionResultEl);
  shadow.append(style, selectionRoot);
  document.documentElement.append(selectionHost);
}
function positionSelectionTranslator(rect) {
  if (!selectionHost) return;
  const margin = 12;
  const left = Math.min(Math.max(rect.left + rect.width / 2, margin), window.innerWidth - margin);
  const shouldPlaceAbove = rect.bottom + 160 > window.innerHeight && rect.top > 160;
  const top = shouldPlaceAbove ? Math.max(margin, rect.top - 8) : Math.min(window.innerHeight - margin, rect.bottom + 8);
  selectionHost.dataset.placement = shouldPlaceAbove ? "top" : "bottom";
  selectionHost.style.setProperty("--rvt-selection-left", `${left}px`);
  selectionHost.style.setProperty("--rvt-selection-top", `${top}px`);
}
async function translateSelectedText() {
  if (!selectedTextForTranslation || !selectionRoot || !selectionResultEl || !selectionButton) return;
  const requestId = ++selectionTranslationRequestId;
  const text = selectedTextForTranslation;
  selectionRoot.dataset.state = "loading";
  selectionButton.disabled = true;
  selectionButton.textContent = "\u7FFB\u8BD1\u4E2D";
  selectionResultEl.textContent = "\u6B63\u5728\u7FFB\u8BD1...";
  try {
    const response = await sendRuntimeMessageSafe({
      type: "page:translate:batch",
      texts: [text],
      targetLanguage: selectionTranslationTargetLanguage
    });
    if (requestId !== selectionTranslationRequestId) return;
    if (!response?.ok) {
      selectionRoot.dataset.state = "error";
      selectionResultEl.textContent = response?.error ?? "\u5212\u8BCD\u7FFB\u8BD1\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u540E\u7AEF\u3002";
      return;
    }
    selectionRoot.dataset.state = "done";
    selectionResultEl.textContent = response.translations?.[0]?.trim() || "\u6CA1\u6709\u8FD4\u56DE\u8BD1\u6587\u3002";
  } catch (error) {
    if (requestId !== selectionTranslationRequestId) return;
    selectionRoot.dataset.state = "error";
    selectionResultEl.textContent = error instanceof Error ? error.message : "\u5212\u8BCD\u7FFB\u8BD1\u5931\u8D25\u3002";
  } finally {
    if (requestId === selectionTranslationRequestId && selectionButton) {
      selectionButton.disabled = false;
      selectionButton.textContent = "\u91CD\u8BD5";
    }
  }
}
function hideSelectionTranslator() {
  if (selectionCheckTimer !== null) {
    window.clearTimeout(selectionCheckTimer);
    selectionCheckTimer = null;
  }
  selectedTextForTranslation = "";
  selectionTranslationRequestId += 1;
  if (selectionHost) selectionHost.dataset.visible = "false";
  if (selectionRoot) selectionRoot.dataset.state = "ready";
  if (selectionPreviewEl) selectionPreviewEl.textContent = "";
  if (selectionResultEl) selectionResultEl.textContent = "";
  if (selectionButton) {
    selectionButton.disabled = false;
    selectionButton.textContent = "\u7FFB\u8BD1";
  }
}
function isSelectionTranslatorEvent(event) {
  if (!selectionHost) return false;
  return event.composedPath().includes(selectionHost);
}
function renderCaption(caption) {
  if (looksLikeBackendErrorText(caption.sourceText) || looksLikeBackendErrorText(caption.translatedText)) return;
  if (!caption.isFinal) return;
  ensureOverlay();
  if (!root || !sourceEl || !translationEl) return;
  if (typeof caption.revision === "number") {
    if (caption.revision < lastCaptionRevision) return;
    lastCaptionRevision = caption.revision;
  }
  lastCaption = caption;
  if (caption.translatedText.trim()) {
    lastStableTranslation = {
      sourceText: caption.sourceText,
      translatedText: caption.translatedText
    };
  }
  activeCaptionVideo = findBestVideo();
  scheduleStableCaptionCommit(caption);
  renderCommittedCaptionLines(caption);
}
function installVideoResumeWatchdog() {
  if (videoResumeWatchdogInstalled) return;
  if (!isExtensionRuntimeAvailable()) return;
  videoResumeWatchdogInstalled = true;
  document.addEventListener("play", handleVideoResumeEvent, true);
  document.addEventListener("playing", handleVideoResumeEvent, true);
  document.addEventListener("pause", handleVideoPauseEvent, true);
  window.addEventListener("focus", handlePageReturnedToForeground);
  document.addEventListener("visibilitychange", handlePageReturnedToForeground);
  window.addEventListener("pageshow", handlePageReturnedToForeground);
}
function handleVideoPauseEvent(event) {
  if (!isExtensionRuntimeAvailable()) return;
  if (!(event.target instanceof HTMLVideoElement)) return;
  videoPauseObserved = true;
  void suspendTranslatorForVideoPause();
}
function handleVideoResumeEvent(event) {
  if (!isExtensionRuntimeAvailable()) return;
  if (!(event.target instanceof HTMLVideoElement)) return;
  if (translatorSuspendedByVideoPause) {
    void resumeTranslatorAfterVideoPause();
    return;
  }
  const shouldForceRestart = videoPauseObserved;
  videoPauseObserved = false;
  scheduleVideoResumeHealthCheck(shouldForceRestart);
}
function handlePageReturnedToForeground() {
  if (!isExtensionRuntimeAvailable()) return;
  if (document.visibilityState === "hidden") {
    videoPauseObserved = true;
    return;
  }
  const video = findBestVideo();
  if (!video || video.paused) return;
  if (translatorSuspendedByVideoPause) {
    void resumeTranslatorAfterVideoPause();
    return;
  }
  const shouldForceRestart = videoPauseObserved;
  videoPauseObserved = false;
  scheduleVideoResumeHealthCheck(shouldForceRestart);
}
async function suspendTranslatorForVideoPause() {
  if (videoPauseSuspendInFlight || translatorSuspendedByVideoPause) return;
  videoPauseSuspendInFlight = true;
  clearCaptionDisplay();
  try {
    const response = await sendRuntimeMessageSafe({ type: "translator:suspend" });
    translatorSuspendedByVideoPause = Boolean(response?.ok && response.running);
  } finally {
    videoPauseSuspendInFlight = false;
  }
}
async function resumeTranslatorAfterVideoPause() {
  if (videoResumeInFlight) return;
  videoResumeInFlight = true;
  try {
    videoPauseObserved = false;
    const response = await sendRuntimeMessageSafe({ type: "translator:resume" });
    if (response?.ok && response.running) {
      translatorSuspendedByVideoPause = false;
      lastVideoResumeRestartAt = Date.now();
      scheduleVideoResumeHealthCheck(false);
      return;
    }
    translatorSuspendedByVideoPause = true;
    lastVideoResumeRestartAt = 0;
    scheduleVideoResumeHealthCheck(true);
  } finally {
    videoResumeInFlight = false;
  }
}
function scheduleVideoResumeHealthCheck(forceRestart = false) {
  if (!isExtensionRuntimeAvailable()) return;
  pendingVideoResumeForceRestart = pendingVideoResumeForceRestart || forceRestart;
  if (videoResumeTimer !== null) window.clearTimeout(videoResumeTimer);
  videoResumeTimer = window.setTimeout(() => {
    const shouldForceRestart = pendingVideoResumeForceRestart;
    pendingVideoResumeForceRestart = false;
    videoResumeTimer = null;
    void restartTranslatorIfCaptionStale(shouldForceRestart);
  }, forceRestart ? VIDEO_RESUME_FORCE_RESTART_DELAY_MS : VIDEO_RESUME_GRACE_MS);
}
async function restartTranslatorIfCaptionStale(forceRestart = false) {
  if (!isExtensionRuntimeAvailable()) return;
  const video = findBestVideo();
  if (!video || video.paused) return;
  const now = Date.now();
  const throttleMs = forceRestart ? VIDEO_RESUME_FORCE_RESTART_THROTTLE_MS : VIDEO_RESUME_RESTART_THROTTLE_MS;
  if (now - lastVideoResumeRestartAt < throttleMs) return;
  const status = await sendRuntimeMessageSafe({ type: "translator:status" });
  if (!status?.ok || !status.running) return;
  const lastReceivedAt = lastCaption?.receivedAt ?? 0;
  if (!forceRestart && lastReceivedAt && now - lastReceivedAt < VIDEO_RESUME_GRACE_MS + 1500) return;
  lastVideoResumeRestartAt = now;
  await sendRuntimeMessageSafe({ type: "translator:start" });
}
function ensureOverlay() {
  ensureNativeCueStyle();
  if (host && document.documentElement.contains(host)) {
    attachOverlayToCurrentLayer();
    updateOverlayPosition();
    return;
  }
  host = document.createElement("div");
  host.id = ROOT_ID;
  host.dataset.visible = "false";
  host.dataset.running = "false";
  const shadow = host.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = SUBTITLE_STYLE;
  root = document.createElement("section");
  root.className = "rvt-subtitle-panel";
  root.dataset.phase = "idle";
  root.dataset.style = subtitleStyle;
  root.dataset.mode = showOriginal && showTranslation ? "bilingual" : "translation";
  const header = document.createElement("div");
  header.className = "rvt-subtitle-header";
  const title = document.createElement("span");
  title.className = "rvt-subtitle-title";
  title.textContent = "\u5B9E\u65F6\u5B57\u5E55";
  statusEl = document.createElement("span");
  statusEl.className = "rvt-subtitle-status";
  header.append(title, statusEl);
  const body = document.createElement("div");
  body.className = "rvt-subtitle-body";
  sourceEl = document.createElement("p");
  sourceEl.className = "rvt-subtitle-source";
  translationEl = document.createElement("p");
  translationEl.className = "rvt-subtitle-translation";
  body.append(sourceEl, translationEl);
  root.append(header, body);
  shadow.append(style, root);
  attachOverlayToCurrentLayer();
  setStatus(false, "mock");
  startPositionTracking();
}
function ensureNativeCueStyle() {
  if (document.getElementById(NATIVE_CUE_STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = NATIVE_CUE_STYLE_ID;
  style.textContent = `
    video::cue {
      background-color: rgba(0, 0, 0, 0.08);
      color: #ffffff;
      text-shadow:
        0 1px 2px rgba(0, 0, 0, 0.85),
        0 0 6px rgba(0, 0, 0, 0.65);
    }
  `;
  document.documentElement.append(style);
}
function setStatus(running, mode) {
  if (!statusEl || !host) return;
  statusEl.textContent = running ? `${mode === "websocket" ? "\u5B9E\u65F6" : "\u6A21\u62DF"}\u8FD0\u884C\u4E2D` : "\u5DF2\u505C\u6B62";
  host.dataset.running = String(running);
  updateOverlayPosition();
}
function clearCaptionDisplay() {
  stopCaptionExpiryTimer();
  stopStableCaptionTimer();
  if (sourceEl) sourceEl.textContent = "";
  if (translationEl) translationEl.textContent = "";
  if (root) root.dataset.phase = "idle";
  if (host) {
    host.dataset.visible = "false";
    host.dataset.running = "false";
  }
  clearNativeCaptionTrack();
  activeCaptionVideo = null;
  lastCaption = null;
  lastStableTranslation = null;
  lastCaptionRevision = 0;
  committedCaptionLines = [];
  committedCaptionSourceKeys = [];
  pendingStableCaption = null;
}
function expireCaptionDisplay() {
  stopStableCaptionTimer();
  if (sourceEl) sourceEl.textContent = "";
  if (translationEl) translationEl.textContent = "";
  if (root) root.dataset.phase = "idle";
  if (host) host.dataset.visible = "false";
  clearNativeCaptionTrack();
  activeCaptionVideo = null;
  lastCaption = null;
  lastStableTranslation = null;
  committedCaptionLines = [];
  committedCaptionSourceKeys = [];
  pendingStableCaption = null;
}
function scheduleCaptionExpiry() {
  stopCaptionExpiryTimer();
  captionExpiryTimer = window.setTimeout(expireCaptionDisplay, CAPTION_STALE_MS);
}
function stopCaptionExpiryTimer() {
  if (captionExpiryTimer === null) return;
  window.clearTimeout(captionExpiryTimer);
  captionExpiryTimer = null;
}
function stopStableCaptionTimer() {
  if (stableCaptionTimer === null) return;
  window.clearTimeout(stableCaptionTimer);
  stableCaptionTimer = null;
}
function startPositionTracking() {
  if (positionTimer !== null) return;
  updateOverlayPosition();
  positionTimer = window.setInterval(updateOverlayPosition, 500);
  window.addEventListener("resize", updateOverlayPosition);
  window.addEventListener("scroll", updateOverlayPosition, true);
  document.addEventListener("fullscreenchange", () => {
    attachOverlayToCurrentLayer();
    updateOverlayPosition();
  });
}
function attachOverlayToCurrentLayer() {
  if (!host) return;
  const fullscreenElement = document.fullscreenElement;
  const parent = fullscreenElement instanceof HTMLVideoElement ? document.documentElement : fullscreenElement ?? document.documentElement;
  if (host.parentElement !== parent) parent.append(host);
  updateNativeCaptionVisibility();
}
function updateOverlayPosition() {
  if (!host) return;
  const video = host.dataset.visible === "true" ? activeCaptionVideo : findBestVideo();
  if (host.dataset.visible === "true" && !isUsableVideoTarget(video)) {
    expireCaptionDisplay();
    return;
  }
  if (!video) {
    host.style.setProperty("--rvt-left", "50%");
    host.style.setProperty("--rvt-bottom", "7vh");
    host.style.setProperty("--rvt-width", "min(760px, calc(100vw - 32px))");
    return;
  }
  const rect = video.getBoundingClientRect();
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const safeGap = Math.max(18, Math.min(54, rect.height * 0.08));
  const bottom = Math.max(16, viewportHeight - Math.min(rect.bottom, viewportHeight) + safeGap);
  const left = Math.min(Math.max(rect.left + rect.width / 2, 16), viewportWidth - 16);
  const widthLimit = document.fullscreenElement ? viewportWidth * 0.86 : Math.min(viewportWidth * 0.82, 1080);
  const width = Math.min(widthLimit, Math.max(360, Math.min(rect.width * 0.82, viewportWidth - 24)));
  host.style.setProperty("--rvt-left", `${left}px`);
  host.style.setProperty("--rvt-bottom", `${bottom}px`);
  host.style.setProperty("--rvt-width", `${width}px`);
}
function findBestVideo() {
  const videos = Array.from(document.querySelectorAll("video"));
  let best = null;
  for (const video of videos) {
    const rect = video.getBoundingClientRect();
    if (rect.width < 120 || rect.height < 80) continue;
    if (rect.bottom <= 0 || rect.right <= 0 || rect.top >= window.innerHeight || rect.left >= window.innerWidth) continue;
    const visibleWidth = Math.min(rect.right, window.innerWidth) - Math.max(rect.left, 0);
    const visibleHeight = Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0);
    const visibleArea = Math.max(0, visibleWidth) * Math.max(0, visibleHeight);
    const playingScore = video.paused ? 0 : 1e6;
    const audibleScore = !video.muted && video.volume > 0 ? 1e5 : 0;
    const progressScore = Number.isFinite(video.currentTime) ? video.currentTime : 0;
    const score = playingScore + audibleScore + visibleArea + progressScore;
    if (!best || score > best.score) best = { video, score };
  }
  return best?.video ?? null;
}
function isUsableVideoTarget(video) {
  if (!video || !document.documentElement.contains(video)) return false;
  const rect = video.getBoundingClientRect();
  if (rect.width < 120 || rect.height < 80) return false;
  if (rect.bottom <= 0 || rect.right <= 0 || rect.top >= window.innerHeight || rect.left >= window.innerWidth) return false;
  return true;
}
function updateNativeCaptionTrack(caption, display = getCommittedDisplayCaption()) {
  if (!shouldUseNativeCaptionLayer()) {
    clearNativeCaptionTrack();
    return;
  }
  const video = activeCaptionVideo ?? findBestVideo();
  if (!video) return;
  const track = ensureNativeCaptionTrack(video);
  if (!track) return;
  clearTextTrack(track);
  const now = Number.isFinite(video.currentTime) ? video.currentTime : 0;
  const duration = Number.isFinite(video.duration) ? video.duration : now + 3;
  const end = Math.min(duration, now + 6);
  const text = [display.sourceText, display.translatedText].filter(Boolean).join("\n");
  if (!text) return;
  const CueConstructor = window.VTTCue ?? window.TextTrackCue;
  if (!CueConstructor) return;
  const cue = new CueConstructor(now, Math.max(now + 0.5, end), text);
  if ("line" in cue) cue.line = -3;
  if ("align" in cue) cue.align = "center";
  if ("position" in cue) cue.position = 50;
  if ("size" in cue) cue.size = 70;
  track.addCue(cue);
  updateNativeCaptionVisibility();
}
function isSameCaptionEvolution(previousSource, currentSource) {
  const previous = normalizeCaptionForCompare(previousSource);
  const current = normalizeCaptionForCompare(currentSource);
  if (!previous || !current) return false;
  if (previous === current) return true;
  if (current.includes(previous)) return false;
  if (!previous.includes(current)) return false;
  return current.length >= 12;
}
function normalizeCaptionForCompare(text) {
  return text.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}
function scheduleStableCaptionCommit(caption) {
  const translatedText = caption.translatedText.trim();
  if (!translatedText) return;
  const hasCompleteSentence = hasSentenceBoundary(caption.sourceText) || hasSentenceBoundary(translatedText);
  const allowFragment = caption.isFinal || !hasCompleteSentence;
  const delayMs = caption.isFinal || hasCompleteSentence ? STABLE_CAPTION_FAST_COMMIT_MS : STABLE_CAPTION_FALLBACK_COMMIT_MS;
  pendingStableCaption = {
    caption: {
      ...caption,
      translatedText
    },
    allowFragment
  };
  stopStableCaptionTimer();
  if (caption.isFinal) {
    commitPendingStableCaption();
    return;
  }
  stableCaptionTimer = window.setTimeout(commitPendingStableCaption, delayMs);
}
function commitPendingStableCaption() {
  stableCaptionTimer = null;
  if (!pendingStableCaption) return;
  const { caption, allowFragment } = pendingStableCaption;
  pendingStableCaption = null;
  const sourceLine = extractStableSourceLine(caption.sourceText, allowFragment);
  if (!sourceLine.text) return;
  const sourceKey = normalizeCaptionForCompare(sourceLine.text);
  if (!sourceKey || hasCommittedCaptionSource(sourceKey)) return;
  const line = extractStableTranslatedLine(caption.translatedText, sourceLine, allowFragment);
  if (!line) return;
  const displayLines = splitSubtitleDisplayLines(line, STABLE_CAPTION_MAX_CHARS);
  if (displayLines.length === 0) return;
  committedCaptionLines = [...committedCaptionLines, ...displayLines].slice(-2);
  committedCaptionSourceKeys = [...committedCaptionSourceKeys, sourceKey].slice(-8);
  renderCommittedCaptionLines(caption);
}
function renderCommittedCaptionLines(caption = lastCaption) {
  if (!sourceEl || !translationEl || !root) return;
  const display = getCommittedDisplayCaption();
  if (host) host.dataset.visible = display.sourceText || display.translatedText ? "true" : "false";
  sourceEl.textContent = display.sourceText;
  translationEl.textContent = display.translatedText;
  sourceEl.toggleAttribute("hidden", !display.sourceText);
  translationEl.toggleAttribute("hidden", !display.translatedText);
  root.dataset.phase = "final";
  if (caption && (display.sourceText || display.translatedText)) {
    updateNativeCaptionTrack(caption, display);
    scheduleCaptionExpiry();
  }
}
function getCommittedDisplayCaption() {
  if (committedCaptionLines.length === 0) return { sourceText: "", translatedText: "" };
  if (committedCaptionLines.length === 1) {
    return { sourceText: "", translatedText: committedCaptionLines[0] ?? "" };
  }
  return {
    sourceText: committedCaptionLines[committedCaptionLines.length - 2] ?? "",
    translatedText: committedCaptionLines[committedCaptionLines.length - 1] ?? ""
  };
}
function extractStableTranslatedLine(text, sourceLine, allowFragment) {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) return "";
  if (allowFragment) return normalized;
  const completeSentences = getCompleteSentences(normalized);
  if (completeSentences.length > 0) {
    return completeSentences[sourceLine.index] ?? completeSentences[completeSentences.length - 1] ?? "";
  }
  if (sourceLine.isComplete || allowFragment) return normalized;
  return "";
}
function extractStableSourceLine(text, allowFragment) {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) return { text: "", index: -1, isComplete: false };
  if (allowFragment) return { text: normalized, index: 0, isComplete: true };
  const completeSentences = getCompleteSentences(normalized);
  if (completeSentences.length > 0) {
    const index = completeSentences.length - 1;
    return { text: completeSentences[index] ?? "", index, isComplete: true };
  }
  return allowFragment ? { text: normalized, index: 0, isComplete: false } : { text: "", index: -1, isComplete: false };
}
function hasCommittedCaptionSource(sourceKey) {
  return committedCaptionSourceKeys.some((existingKey) => existingKey === sourceKey || isSameCaptionEvolution(existingKey, sourceKey));
}
function splitSubtitleDisplayLines(text, maxChars) {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) return [];
  const segments = normalized.split(/(?<=[，,。.!?！？；;：:])\s*/u).map((segment) => segment.trim()).filter(Boolean);
  const lines = [];
  let current = "";
  for (const segment of segments.length > 0 ? segments : [normalized]) {
    if (segment.length > maxChars) {
      if (current) {
        lines.push(current);
        current = "";
      }
      lines.push(...splitLongSubtitleLine(segment, maxChars));
      continue;
    }
    const candidate = current ? `${current}${segment}` : segment;
    if (candidate.length <= maxChars) {
      current = candidate;
      continue;
    }
    if (current) lines.push(current);
    current = segment;
  }
  if (current) lines.push(current);
  return mergeShortSubtitleTails(lines, maxChars).map(normalizeSubtitleDisplayLine).filter(isMeaningfulSubtitleLine);
}
function normalizeSubtitleDisplayLine(text) {
  return text.replace(/\s+/g, " ").trim().replace(/[。.]+([）)\]】」』”"']*)$/u, "$1").trim();
}
function splitLongSubtitleLine(text, maxChars) {
  const normalized = text.trim();
  const lines = [];
  for (let index = 0; index < normalized.length; index += maxChars) {
    lines.push(normalized.slice(index, index + maxChars).trim());
  }
  return lines.filter(Boolean);
}
function mergeShortSubtitleTails(lines, maxChars) {
  const merged = [];
  for (const line of lines) {
    const previous = merged[merged.length - 1];
    if (previous && line.length < STABLE_CAPTION_MIN_CHARS && previous.length + line.length <= maxChars + STABLE_CAPTION_MIN_CHARS) {
      merged[merged.length - 1] = `${previous}${line}`;
      continue;
    }
    merged.push(line);
  }
  return merged;
}
function isMeaningfulSubtitleLine(line) {
  const normalized = line.replace(/\s+/g, "").trim();
  if (!normalized) return false;
  if (normalized.length >= STABLE_CAPTION_MIN_CHARS) return true;
  return /[。.!?！？]$/u.test(normalized) && normalized.length >= 4;
}
function looksLikeBackendErrorText(text) {
  return /timeout waiting next packet|server[_\s-]?error|火山\s*asr\s*错误|backend connection failed|后端连接失败|"\s*error\s*"\s*:/i.test(
    text
  );
}
async function sendRuntimeMessageSafe(message) {
  try {
    if (!isExtensionRuntimeAvailable()) return void 0;
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    if (isExtensionContextInvalidated(error)) {
      markExtensionContextInvalidated();
      return void 0;
    }
    throw error;
  }
}
function handleUnhandledRejection(event) {
  if (!isExtensionContextInvalidated(event.reason)) return;
  event.preventDefault();
  markExtensionContextInvalidated();
}
function isExtensionRuntimeAvailable() {
  if (extensionContextInvalidated) return false;
  try {
    return Boolean(chrome.runtime?.id);
  } catch (error) {
    if (isExtensionContextInvalidated(error)) {
      markExtensionContextInvalidated();
      return false;
    }
    throw error;
  }
}
function markExtensionContextInvalidated() {
  if (extensionContextInvalidated) return;
  extensionContextInvalidated = true;
  stopStableCaptionTimer();
  stopCaptionExpiryTimer();
  if (videoResumeTimer !== null) {
    window.clearTimeout(videoResumeTimer);
    videoResumeTimer = null;
  }
  if (autoPageTranslationTimer !== null) {
    window.clearTimeout(autoPageTranslationTimer);
    autoPageTranslationTimer = null;
  }
  if (selectionCheckTimer !== null) {
    window.clearTimeout(selectionCheckTimer);
    selectionCheckTimer = null;
  }
  hideSelectionTranslator();
  stopPageTranslationObserver();
  removeDomEventListeners();
}
function cleanupContentScript() {
  stopStableCaptionTimer();
  stopCaptionExpiryTimer();
  if (videoResumeTimer !== null) {
    window.clearTimeout(videoResumeTimer);
    videoResumeTimer = null;
  }
  if (autoPageTranslationTimer !== null) {
    window.clearTimeout(autoPageTranslationTimer);
    autoPageTranslationTimer = null;
  }
  if (selectionCheckTimer !== null) {
    window.clearTimeout(selectionCheckTimer);
    selectionCheckTimer = null;
  }
  stopPageTranslationObserver();
  if (positionTimer !== null) {
    window.clearInterval(positionTimer);
    positionTimer = null;
  }
  selectionHost?.remove();
  selectionHost = null;
  selectionRoot = null;
  selectionPreviewEl = null;
  selectionResultEl = null;
  selectionButton = null;
  selectionCloseButton = null;
  removeDomEventListeners();
  window.removeEventListener("unhandledrejection", handleUnhandledRejection);
  if (isExtensionRuntimeAvailable()) {
    chrome.runtime.onMessage.removeListener(handleRuntimeMessage);
    chrome.storage.onChanged.removeListener(handleStorageChanged);
  }
  if (originalPushState) {
    history.pushState = originalPushState;
    originalPushState = null;
  }
  if (originalReplaceState) {
    history.replaceState = originalReplaceState;
    originalReplaceState = null;
  }
  if (rvtWindow.__rvtContentScriptCleanup === cleanupContentScript) {
    delete rvtWindow.__rvtContentScriptCleanup;
  }
}
function removeDomEventListeners() {
  document.removeEventListener("play", handleVideoResumeEvent, true);
  document.removeEventListener("playing", handleVideoResumeEvent, true);
  document.removeEventListener("pause", handleVideoPauseEvent, true);
  window.removeEventListener("focus", handlePageReturnedToForeground);
  document.removeEventListener("visibilitychange", handlePageReturnedToForeground);
  window.removeEventListener("pageshow", handlePageReturnedToForeground);
  window.removeEventListener("popstate", handlePageUrlMaybeChanged);
  window.removeEventListener("hashchange", handlePageUrlMaybeChanged);
  window.removeEventListener("pageshow", handleAutoPageShow);
  document.removeEventListener("selectionchange", handleSelectionChange);
  document.removeEventListener("mouseup", handleSelectionGestureComplete, true);
  document.removeEventListener("keyup", handleSelectionGestureComplete, true);
  document.removeEventListener("mousedown", handleSelectionOutsideMouseDown, true);
  window.removeEventListener("scroll", handleSelectionViewportChanged, true);
  window.removeEventListener("resize", handleSelectionViewportChanged);
  videoResumeWatchdogInstalled = false;
  autoPageTranslationWatchersInstalled = false;
  selectionTranslationWatchersInstalled = false;
}
function isExtensionContextInvalidated(error) {
  const message = error instanceof Error ? error.message : String(error ?? "");
  return message.includes("Extension context invalidated") || message.includes("Extension context was invalidated");
}
function getCompleteSentences(text) {
  return text.match(/[^.!?。！？]+[.!?。！？]+/g)?.map((sentence) => sentence.trim()).filter(Boolean) ?? [];
}
function hasSentenceBoundary(text) {
  return /[.!?。！？]/.test(text);
}
function ensureNativeCaptionTrack(video) {
  if (nativeCaptionVideo === video && nativeCaptionTrack) return nativeCaptionTrack;
  nativeCaptionVideo = video;
  const trackElement = document.createElement("track");
  trackElement.kind = "captions";
  trackElement.label = "\u5B9E\u65F6\u89C6\u9891\u7FFB\u8BD1";
  trackElement.srclang = "zh-CN";
  trackElement.default = true;
  trackElement.dataset.rvtNativeTrack = "true";
  video.append(trackElement);
  nativeCaptionTrack = trackElement.track;
  nativeCaptionTrack.mode = shouldUseNativeCaptionLayer() ? "showing" : "hidden";
  return nativeCaptionTrack;
}
function updateNativeCaptionVisibility() {
  if (!nativeCaptionTrack) return;
  nativeCaptionTrack.mode = shouldUseNativeCaptionLayer() ? "showing" : "hidden";
  if (lastCaption && shouldUseNativeCaptionLayer() && nativeCaptionTrack.cues?.length === 0) {
    updateNativeCaptionTrack(lastCaption);
  }
}
function shouldUseNativeCaptionLayer() {
  return document.fullscreenElement instanceof HTMLVideoElement;
}
function clearNativeCaptionTrack() {
  if (nativeCaptionTrack) clearTextTrack(nativeCaptionTrack);
}
function clearTextTrack(track) {
  const cues = track.cues;
  if (!cues) return;
  for (let index = cues.length - 1; index >= 0; index -= 1) {
    const cue = cues[index];
    if (cue) track.removeCue(cue);
  }
}
function groupCandidatesByParentFlat(candidates) {
  const byParent = /* @__PURE__ */ new Map();
  for (const item of candidates) {
    const parent = item.node.parentElement;
    if (!parent) continue;
    const bucket = byParent.get(parent);
    if (bucket) bucket.push(item);
    else byParent.set(parent, [item]);
  }
  const seenParents = [];
  const seen = /* @__PURE__ */ new Set();
  for (const item of candidates) {
    const parent = item.node.parentElement;
    if (parent && !seen.has(parent)) {
      seen.add(parent);
      seenParents.push(parent);
    }
  }
  const flat = [];
  for (const parent of seenParents) {
    const bucket = byParent.get(parent);
    if (bucket) flat.push(...bucket);
  }
  return flat;
}
async function translatePage(targetLanguage) {
  const runId = ++activePageTranslationRunId;
  pruneTranslatedTextNodes();
  let candidates = collectTranslatableTextNodes();
  if (candidates.length === 0 && translatedTextNodes.length > 0) {
    if (autoTriggeredTranslateRunning) return 0;
    restorePage();
    candidates = collectTranslatableTextNodes();
  }
  if (candidates.length === 0) return 0;
  const ordered = groupCandidatesByParentFlat(candidates);
  const batches = [];
  for (let index = 0; index < ordered.length; index += PAGE_TRANSLATION_BATCH_SIZE) {
    batches.push(ordered.slice(index, index + PAGE_TRANSLATION_BATCH_SIZE));
  }
  const totalBatches = batches.length;
  let completedBatches = 0;
  let nextBatchIndex = 0;
  await Promise.all(
    Array.from({ length: Math.min(PAGE_TRANSLATION_CONCURRENCY, batches.length) }, async () => {
      while (nextBatchIndex < batches.length) {
        const batch = batches[nextBatchIndex];
        nextBatchIndex += 1;
        if (!batch || batch.length === 0) continue;
        await translatePageBatch(batch, targetLanguage, runId);
        completedBatches += 1;
        void chrome.runtime.sendMessage({
          type: "page:translate:progress",
          runId,
          translated: translatedTextNodes.length,
          total: candidates.length,
          batchIndex: completedBatches,
          totalBatches
        }).catch(() => void 0);
      }
    })
  );
  return translatedTextNodes.length;
}
async function translatePageBatch(batch, targetLanguage, runId) {
  const texts = batch.map((item) => item.trimmed);
  const response = await sendRuntimeMessageSafe({
    type: "page:translate:batch",
    texts,
    targetLanguage
  });
  if (!response?.ok) throw new Error(response?.error ?? "\u7F51\u9875\u7FFB\u8BD1\u5931\u8D25\u3002");
  const translations = response.translations ?? [];
  batch.forEach((item, itemIndex) => {
    if (runId !== activePageTranslationRunId) return;
    const translated = translations[itemIndex];
    if (item.node.nodeValue !== item.original) return;
    if (isTranslatedTextNode(item.node)) return;
    const finalText = translated || item.trimmed;
    if (!finalText.trim()) return;
    translatedTextNodes.push({ node: item.node, original: item.original });
    if (translatedTextNodes.length > TRANSLATED_NODE_HISTORY_LIMIT) {
      translatedTextNodes = translatedTextNodes.slice(-TRANSLATED_NODE_HISTORY_LIMIT);
    }
    pausePageTranslationObserver();
    try {
      item.node.nodeValue = `${item.leading}${finalText}${item.trailing}`;
    } finally {
      resumePageTranslationObserver();
    }
  });
}
function restorePage() {
  activePageTranslationRunId += 1;
  const restored = translatedTextNodes.length;
  pausePageTranslationObserver();
  try {
    for (const item of translatedTextNodes) {
      if (document.documentElement.contains(item.node)) item.node.nodeValue = item.original;
    }
  } finally {
    resumePageTranslationObserver();
  }
  translatedTextNodes = [];
  clearSkipElementCache();
  return restored;
}
function pruneTranslatedTextNodes() {
  translatedTextNodes = translatedTextNodes.filter((item) => document.documentElement.contains(item.node));
}
function collectTranslatableTextNodes() {
  const nodes = [];
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const text = node.nodeValue ?? "";
      const trimmed = text.trim();
      if (trimmed.length < 2 || !/[A-Za-z]/.test(trimmed)) return NodeFilter.FILTER_REJECT;
      if (trimmed.length > PAGE_TRANSLATION_MAX_NODE_CHARS) return NodeFilter.FILTER_REJECT;
      const parent = node.parentElement;
      if (!parent || shouldSkipTranslationElement(parent)) return NodeFilter.FILTER_REJECT;
      if (isTranslatedTextNode(node)) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  let current = walker.nextNode();
  while (current && nodes.length < PAGE_TRANSLATION_MAX_NODES) {
    const node = current;
    const original = node.nodeValue ?? "";
    const trimmed = original.trim();
    nodes.push({
      node,
      original,
      trimmed,
      leading: original.match(/^\s*/)?.[0] ?? "",
      trailing: original.match(/\s*$/)?.[0] ?? ""
    });
    current = walker.nextNode();
  }
  return nodes;
}
function isTranslatedTextNode(node) {
  return translatedTextNodes.some((item) => item.node === node);
}
var skipElementCache = /* @__PURE__ */ new WeakMap();
function shouldSkipTranslationElement(element) {
  const cached = skipElementCache.get(element);
  if (cached !== void 0) return cached;
  if (element.closest(`#${ROOT_ID}, #${SELECTION_ROOT_ID}`)) {
    skipElementCache.set(element, true);
    return true;
  }
  if (element.closest("script, style, noscript, textarea, input, select, option, code, pre, kbd, samp, svg, canvas, iframe")) {
    skipElementCache.set(element, true);
    return true;
  }
  if (element.closest("[contenteditable='true'], [contenteditable='']")) {
    skipElementCache.set(element, true);
    return true;
  }
  if (element.closest("[aria-hidden='true'], [hidden]")) {
    skipElementCache.set(element, true);
    return true;
  }
  const style = window.getComputedStyle(element);
  if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
    skipElementCache.set(element, true);
    return true;
  }
  if (element.getClientRects().length === 0) {
    skipElementCache.set(element, true);
    return true;
  }
  skipElementCache.set(element, false);
  return false;
}
function clearSkipElementCache() {
  skipElementCache.clear?.();
}
var SELECTION_TRANSLATOR_STYLE = `
  :host {
    position: fixed !important;
    left: var(--rvt-selection-left, 50%) !important;
    top: var(--rvt-selection-top, 0) !important;
    z-index: 2147483647 !important;
    width: min(360px, calc(100vw - 24px)) !important;
    transform: translateX(-50%) !important;
    pointer-events: none !important;
    opacity: 0 !important;
    transition:
      opacity 120ms ease,
      transform 120ms ease !important;
  }

  :host([data-visible="true"]) {
    opacity: 1 !important;
  }

  :host([data-placement="top"]) {
    transform: translateX(-50%) translateY(-100%) !important;
  }

  .rvt-selection-panel {
    box-sizing: border-box;
    display: grid;
    gap: 8px;
    width: 100%;
    max-height: min(320px, calc(100vh - 24px));
    overflow: auto;
    padding: 10px;
    border: 1px solid rgba(148, 163, 184, 0.35);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.98);
    color: #111827;
    box-shadow: 0 12px 30px rgba(15, 23, 42, 0.22);
    font-family:
      Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    pointer-events: auto;
  }

  .rvt-selection-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .rvt-selection-action,
  .rvt-selection-close {
    appearance: none;
    border: 0;
    border-radius: 6px;
    font: inherit;
    cursor: pointer;
  }

  .rvt-selection-action {
    min-height: 28px;
    padding: 0 12px;
    background: #111827;
    color: #ffffff;
    font-size: 12px;
    font-weight: 750;
  }

  .rvt-selection-action:disabled {
    cursor: default;
    opacity: 0.72;
  }

  .rvt-selection-close {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 26px;
    height: 26px;
    background: #f3f4f6;
    color: #4b5563;
    font-size: 16px;
    line-height: 1;
  }

  .rvt-selection-source,
  .rvt-selection-result {
    margin: 0;
    overflow-wrap: anywhere;
    white-space: pre-wrap;
    line-height: 1.45;
  }

  .rvt-selection-source {
    color: #6b7280;
    font-size: 12px;
  }

  .rvt-selection-result {
    color: #111827;
    font-size: 14px;
    font-weight: 650;
  }

  .rvt-selection-panel[data-state="ready"] .rvt-selection-result:empty {
    display: none;
  }

  .rvt-selection-panel[data-state="loading"] .rvt-selection-result {
    color: #2563eb;
  }

  .rvt-selection-panel[data-state="error"] .rvt-selection-result {
    color: #dc2626;
  }
`;
var SUBTITLE_STYLE = `
  :host {
    position: fixed !important;
    left: var(--rvt-left, 50%) !important;
    bottom: var(--rvt-bottom, 7vh) !important;
    z-index: 2147483647 !important;
    width: var(--rvt-width, min(900px, calc(100vw - 24px))) !important;
    transform: translateX(-50%) !important;
    box-sizing: border-box !important;
    pointer-events: none !important;
    opacity: 0 !important;
    transition:
      opacity 160ms ease,
      transform 160ms ease !important;
  }

  :host([data-visible="true"]) {
    opacity: 1 !important;
    transform: translateX(-50%) translateY(0) !important;
  }

  .rvt-subtitle-panel {
    box-sizing: border-box;
    width: 100%;
    padding: 0 8px;
    border: 0;
    border-radius: 0;
    background: transparent;
    color: #f8fafc;
    box-shadow: none;
    font-family:
      Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    backdrop-filter: none;
  }

  .rvt-subtitle-header {
    display: none;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 6px;
    color: rgba(226, 232, 240, 0.8);
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0;
    text-transform: uppercase;
  }

  .rvt-subtitle-status {
    color: #67e8f9;
    text-transform: none;
  }

  .rvt-subtitle-body {
    display: grid;
    gap: 6px;
  }

  .rvt-subtitle-source,
  .rvt-subtitle-translation {
    margin: 0;
    overflow-wrap: anywhere;
    white-space: pre-line;
    text-align: center;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .rvt-subtitle-source {
    color: rgba(226, 232, 240, 0.86);
    font-size: clamp(18px, 1.65vw, 28px);
    font-weight: 650;
    line-height: 1.28;
    text-shadow:
      0 1px 2px rgba(0, 0, 0, 0.85),
      0 0 5px rgba(0, 0, 0, 0.65);
    -webkit-line-clamp: 1;
  }

  .rvt-subtitle-translation {
    color: #ffffff;
    font-size: clamp(22px, 1.9vw, 32px);
    font-weight: 750;
    line-height: 1.22;
    text-shadow:
      0 2px 3px rgba(0, 0, 0, 0.9),
      0 0 8px rgba(0, 0, 0, 0.72);
    -webkit-line-clamp: 2;
  }

  .rvt-subtitle-source[hidden],
  .rvt-subtitle-translation[hidden] {
    display: none !important;
  }

  .rvt-subtitle-panel[data-mode="bilingual"] .rvt-subtitle-body {
    gap: 4px;
  }

  .rvt-subtitle-panel[data-mode="bilingual"] .rvt-subtitle-source {
    color: rgba(229, 231, 235, 0.9);
    font-size: clamp(16px, 1.45vw, 24px);
    font-weight: 620;
  }

  .rvt-subtitle-panel[data-mode="bilingual"] .rvt-subtitle-translation {
    font-size: clamp(20px, 1.72vw, 30px);
    -webkit-line-clamp: 2;
  }

  .rvt-subtitle-panel[data-phase="interim"] .rvt-subtitle-translation {
    color: #dbeafe;
  }

  .rvt-subtitle-panel[data-style="normal"] .rvt-subtitle-source {
    font-weight: 560;
    text-shadow:
      0 1px 2px rgba(0, 0, 0, 0.72),
      0 0 4px rgba(0, 0, 0, 0.48);
  }

  .rvt-subtitle-panel[data-style="normal"] .rvt-subtitle-translation {
    font-size: clamp(20px, 1.72vw, 30px);
    font-weight: 650;
    text-shadow:
      0 2px 2px rgba(0, 0, 0, 0.78),
      0 0 6px rgba(0, 0, 0, 0.54);
  }

  .rvt-subtitle-panel[data-style="soft"] .rvt-subtitle-source {
    color: rgba(241, 245, 249, 0.82);
    font-weight: 520;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.65);
  }

  .rvt-subtitle-panel[data-style="soft"] .rvt-subtitle-translation {
    color: rgba(255, 255, 255, 0.92);
    font-size: clamp(19px, 1.62vw, 28px);
    font-weight: 600;
    text-shadow:
      0 1px 2px rgba(0, 0, 0, 0.72),
      0 0 5px rgba(0, 0, 0, 0.5);
  }

  @media (max-width: 640px) {
    :host {
      bottom: 16px !important;
      width: calc(100vw - 20px) !important;
    }

    .rvt-subtitle-panel {
      padding: 0 6px;
    }

    .rvt-subtitle-header {
      font-size: 10px;
    }
  }
`;
if (IS_TOP_FRAME) ensureOverlay();
//# sourceMappingURL=contentScript.js.map
