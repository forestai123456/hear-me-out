// src/types.ts
var DEFAULT_SETTINGS = {
  schemaVersion: 7,
  enabled: true,
  targetLanguage: "zh-CN",
  backendUrl: "ws://localhost:8787/realtime",
  asr: {
    provider: "volcengine",
    appId: "",
    accessToken: "",
    apiKey: "",
    apiSecret: "",
    secretId: "",
    secretKey: "",
    appKey: "",
    resourceId: "volc.seedasr.sauc.duration",
    endpoint: "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_async",
    model: "doubao-seed-asr"
  },
  translation: {
    provider: "microsoft",
    protocol: "openai",
    apiKey: "",
    baseUrl: "",
    model: "",
    disableThinking: true
  },
  mockWhenBackendMissing: false,
  autoTranslatePages: false,
  selectionTranslationEnabled: false,
  showOriginal: false,
  showTranslation: true,
  subtitleStyle: "bold",
  floating: true
};

// src/popup/popup.ts
var ASR_PRESETS = {
  volcengine: {
    hint: "\u5728\u706B\u5C71\u5F15\u64CE\u521B\u5EFA\u201C\u8C46\u5305\u6D41\u5F0F\u8BED\u97F3\u8BC6\u522B\u6A21\u578B 2.0\u201D\u5E94\u7528\u540E\u586B\u5199 App ID \u548C Access Token\u3002",
    fields: ["appId", "accessToken", "resourceId", "endpoint", "model"],
    defaults: {
      endpoint: "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_async",
      model: "doubao-seed-asr",
      resourceId: "volc.seedasr.sauc.duration"
    },
    models: ["doubao-seed-asr"]
  },
  aliyun: {
    hint: "\u5728\u963F\u91CC\u4E91\u767E\u70BC\u521B\u5EFA API Key\u3002\u9ED8\u8BA4\u8D70 Qwen-ASR \u5B9E\u65F6\u534F\u8BAE\uFF1B\u65E7 NLS \u53EF\u5728\u672C\u673A .env \u91CC\u7EE7\u7EED\u914D\u7F6E AppKey + Token\u3002",
    fields: ["apiKey", "endpoint", "model"],
    defaults: {
      endpoint: "wss://dashscope.aliyuncs.com/api-ws/v1/realtime",
      model: "qwen3-asr-flash-realtime"
    },
    models: ["qwen3-asr-flash-realtime"]
  },
  tencent: {
    hint: "\u5728\u817E\u8BAF\u4E91\u8BED\u97F3\u8BC6\u522B\u5F00\u901A\u5B9E\u65F6\u8BC6\u522B\uFF0C\u586B\u5199 AppID\u3001SecretId \u548C SecretKey\u3002",
    fields: ["appId", "secretId", "secretKey", "endpoint", "model"],
    defaults: {
      endpoint: "wss://asr.cloud.tencent.com/asr/v2",
      model: "16k_en"
    },
    models: ["16k_en", "16k_zh", "16k_zh-PY"]
  },
  baidu: {
    hint: "\u5728\u767E\u5EA6\u667A\u80FD\u4E91\u8BED\u97F3\u6280\u672F\u5F00\u901A\u5B9E\u65F6\u8BED\u97F3\u8BC6\u522B\uFF0C\u586B\u5199 AppID \u548C API Key\u3002",
    fields: ["appId", "appKey", "endpoint", "model"],
    defaults: {
      endpoint: "wss://vop.baidu.com/realtime_asr",
      model: "17372"
    },
    models: ["17372", "1737", "15372", "1537"]
  },
  iflytek: {
    hint: "\u5728\u8BAF\u98DE\u5F00\u653E\u5E73\u53F0\u5F00\u901A\u5B9E\u65F6\u8BED\u97F3\u8F6C\u5199\uFF0C\u586B\u5199 AppID \u548C API Key\u3002",
    fields: ["appId", "apiKey", "endpoint", "model"],
    defaults: {
      endpoint: "wss://rtasr.xfyun.cn/v1/ws",
      model: "en"
    },
    models: ["en", "cn"]
  }
};
var TRANSLATION_PRESETS = {
  microsoft: {
    hint: "\u65E0\u9700 API Key\uFF0C\u901F\u5EA6\u5FEB\uFF1B\u51C6\u786E\u5EA6\u4E00\u822C\uFF0C\u9002\u5408\u7F51\u9875\u548C\u5B57\u5E55\u5FEB\u901F\u7FFB\u8BD1\u3002",
    defaults: { protocol: "openai", baseUrl: "", model: "" },
    models: []
  },
  deepseek: {
    hint: "\u586B\u5199 DeepSeek API Key\u3002\u63A8\u8350\u5B57\u5E55\u7528 Flash\uFF0C\u957F\u6587\u53EF\u6362 Pro\u3002",
    defaults: { protocol: "openai", baseUrl: "https://api.deepseek.com", model: "deepseek-v4-flash" },
    anthropicBaseUrl: "https://api.deepseek.com/anthropic",
    models: ["deepseek-v4-flash", "deepseek-v4-pro"]
  },
  mimo: {
    hint: "\u586B\u5199\u5C0F\u7C73 MiMo Platform API Key\u3002MiMo \u4F7F\u7528 api-key \u9274\u6743\u5934\uFF0C\u63D2\u4EF6\u4F1A\u81EA\u52A8\u5904\u7406\u3002",
    defaults: { protocol: "openai", baseUrl: "https://api.xiaomimimo.com/v1", model: "mimo-v2.5-pro" },
    anthropicBaseUrl: "https://api.xiaomimimo.com/anthropic",
    models: ["mimo-v2.5-pro"]
  },
  kimi: {
    hint: "\u586B\u5199 Kimi \u5F00\u653E\u5E73\u53F0 API Key\u3002",
    defaults: { protocol: "openai", baseUrl: "https://api.moonshot.cn/v1", model: "kimi-k2.6" },
    models: ["kimi-k2.6", "kimi-k2.7-code"]
  },
  glm: {
    hint: "\u586B\u5199\u667A\u8C31 / GLM API Key\u3002\u9ED8\u8BA4\u4F7F\u7528 GLM-5.1\uFF1B\u63A5\u53E3\u5730\u5740\u53EF\u6309\u4F60\u8D26\u53F7\u5957\u9910\u8C03\u6574\u3002",
    defaults: { protocol: "openai", baseUrl: "https://open.bigmodel.cn/api/paas/v4", model: "glm-5.1" },
    anthropicBaseUrl: "https://open.bigmodel.cn/api/anthropic",
    models: ["glm-5.1", "glm-4.6", "glm-4.5", "glm-4-flash"]
  },
  qwen: {
    hint: "\u586B\u5199\u963F\u91CC\u4E91\u767E\u70BC API Key\u3002",
    defaults: { protocol: "openai", baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1", model: "qwen-flash" },
    models: ["qwen-flash", "qwen-plus", "qwen-turbo", "qwen-max"]
  },
  minimax: {
    hint: "\u586B\u5199 MiniMax API Key\uFF0C\u53EF\u9009\u62E9 OpenAI \u6216 Anthropic \u517C\u5BB9\u534F\u8BAE\u3002",
    defaults: { protocol: "openai", baseUrl: "https://api.minimaxi.com/v1", model: "MiniMax-M3" },
    anthropicBaseUrl: "https://api.minimaxi.com/anthropic",
    models: ["MiniMax-M3", "MiniMax-M2.7", "MiniMax-M2.7-highspeed"]
  },
  custom: {
    hint: "\u9009\u62E9\u534F\u8BAE\u540E\u586B\u5199\u517C\u5BB9\u63A5\u53E3\u5730\u5740\u3001API Key \u548C\u6A21\u578B\u540D\u3002",
    defaults: { protocol: "openai", baseUrl: "", model: "" },
    models: []
  }
};
var subtitleToggle = getElement("subtitleToggle");
var translationModeInput = getElement("translationMode");
var subtitleStyleInput = getElement("subtitleStyle");
var translatePageButton = getElement("translatePage");
var restorePageButton = getElement("restorePage");
var autoTranslatePagesInput = getElement("autoTranslatePages");
var selectionTranslationInput = getElement("selectionTranslation");
var targetLanguageInput = getElement("targetLanguage");
var asrProviderInput = getElement("asrProvider");
var asrAppIdInput = getElement("asrAppId");
var asrAccessTokenInput = getElement("asrAccessToken");
var asrApiKeyInput = getElement("asrApiKey");
var asrApiSecretInput = getElement("asrApiSecret");
var asrSecretIdInput = getElement("asrSecretId");
var asrSecretKeyInput = getElement("asrSecretKey");
var asrAppKeyInput = getElement("asrAppKey");
var asrResourceIdInput = getElement("asrResourceId");
var asrEndpointInput = getElement("asrEndpoint");
var asrModelInput = getElement("asrModel");
var asrModelOptions = getElement("asrModelOptions");
var asrCredentialHint = getElement("asrCredentialHint");
var translationProviderInput = getElement("translationProvider");
var translationProtocolInput = getElement("translationProtocol");
var translationApiKeyInput = getElement("translationApiKey");
var translationBaseUrlInput = getElement("translationBaseUrl");
var translationModelInput = getElement("translationModel");
var translationDisableThinkingInput = getElement("translationDisableThinking");
var translationModelOptions = getElement("translationModelOptions");
var translationCredentialHint = getElement("translationCredentialHint");
var messageEl = getElement("message");
var initialized = false;
void init();
async function init() {
  let settingsResponse;
  try {
    settingsResponse = await send({ type: "translator:settings:get" });
  } catch {
    settingsResponse = void 0;
  }
  if (settingsResponse?.ok && settingsResponse.settings) {
    renderSettings(settingsResponse.settings);
  } else {
    renderFallbackSettings();
  }
  try {
    await refreshStatus();
  } catch {
  }
  bindEvents();
  installPageTranslationProgressListener();
  initialized = true;
}
function installPageTranslationProgressListener() {
  try {
    chrome.runtime.onMessage.addListener((message) => {
      if (!message || typeof message !== "object") return;
      const candidate = message;
      if (candidate.type === "page:translate:progress") {
        const done = candidate.batchIndex ?? 0;
        const total = candidate.totalBatches ?? 0;
        const translated = candidate.translated ?? 0;
        showMessage(`\u6B63\u5728\u7FFB\u8BD1\u2026 ${done}/${total} \u6279\uFF0C\u5DF2\u5B8C\u6210 ${translated} \u4E2A\u6587\u672C\u5757`);
        return;
      }
      if (candidate.type === "page:translate:done") {
        if (candidate.error) {
          messageEl.textContent = `\u7FFB\u8BD1\u5931\u8D25\uFF1A${candidate.error}`;
          messageEl.dataset.error = "true";
        } else {
          showMessage(`\u5DF2\u7FFB\u8BD1 ${candidate.translated ?? 0} \u4E2A\u6587\u672C\u5757\u3002`);
        }
      }
    });
  } catch {
  }
}
function bindEvents() {
  subtitleToggle.addEventListener("change", async () => {
    await saveSettings();
    try {
      const response = await send({ type: subtitleToggle.checked ? "translator:start" : "translator:stop" });
      renderResponse(response, subtitleToggle.checked ? "\u89C6\u9891\u5B9E\u65F6\u7FFB\u8BD1\u5DF2\u5F00\u59CB\u3002" : "\u89C6\u9891\u5B9E\u65F6\u7FFB\u8BD1\u5DF2\u505C\u6B62\u3002");
    } catch {
      renderFallbackStatus();
    }
    await refreshStatus();
  });
  asrProviderInput.addEventListener("change", async () => {
    applyAsrPreset(asrProviderInput.value, true);
    await saveSettings();
  });
  translationProviderInput.addEventListener("change", async () => {
    applyTranslationPreset(translationProviderInput.value, true);
    await saveSettings();
  });
  translationProtocolInput.addEventListener("change", async () => {
    applyTranslationProtocolDefault();
    await saveSettings();
  });
  translatePageButton.addEventListener("click", () => {
    translatePageButton.disabled = true;
    showMessage("\u6B63\u5728\u542F\u52A8\u7FFB\u8BD1\u2026");
    void (async () => {
      await saveSettings();
      showMessage("\u6B63\u5728\u7FFB\u8BD1\u9875\u9762\u2026\uFF08\u8BF7\u5207\u56DE\u7F51\u9875\u67E5\u770B\u8FDB\u5EA6\uFF0C\u7FFB\u8BD1\u5B8C\u6210\u540E\u8FD9\u91CC\u4F1A\u663E\u793A\u7ED3\u679C\uFF09");
      try {
        const response = await send({ type: "page:translate", targetLanguage: targetLanguageInput.value });
        renderResponse(
          response,
          response?.ok && response.pdfTranslationUrl ? `\u5DF2\u6253\u5F00 PDF \u7FFB\u8BD1\u7ED3\u679C\uFF0C\u5171 ${response.translated ?? 0} \u4E2A\u6587\u672C\u5757\u3002` : response?.ok ? `\u5DF2\u7FFB\u8BD1 ${response.translated ?? 0} \u4E2A\u6587\u672C\u5757\u3002` : "\u7F51\u9875\u7FFB\u8BD1\u5931\u8D25\u3002"
        );
      } catch {
        showMessage("\u7F51\u9875\u7FFB\u8BD1\u8BF7\u6C42\u5931\u8D25\u3002");
      } finally {
        translatePageButton.disabled = false;
      }
    })();
  });
  restorePageButton.addEventListener("click", async () => {
    autoTranslatePagesInput.checked = false;
    await saveSettings();
    try {
      const response = await send({ type: "page:restore" });
      renderResponse(response, response?.ok ? `\u5DF2\u6062\u590D ${response.restored ?? 0} \u4E2A\u6587\u672C\u5757\u3002` : "\u6062\u590D\u5931\u8D25\u3002");
    } catch {
      showMessage("\u6062\u590D\u5931\u8D25\u3002");
    }
  });
  autoTranslatePagesInput.addEventListener("change", async () => {
    await saveSettings();
    if (autoTranslatePagesInput.checked) {
      try {
        const response = await send({ type: "page:translate", targetLanguage: targetLanguageInput.value });
        if (!response?.ok && response?.error?.includes("chrome://")) {
          showMessage("\u81EA\u52A8\u7F51\u9875\u7FFB\u8BD1\u5DF2\u5F00\u542F\u3002\u6253\u5F00\u666E\u901A\u7F51\u9875\u540E\u4F1A\u81EA\u52A8\u7FFB\u8BD1\u3002");
          return;
        }
        renderResponse(response, "\u81EA\u52A8\u7F51\u9875\u7FFB\u8BD1\u5DF2\u5F00\u542F\u3002");
      } catch {
        showMessage("\u81EA\u52A8\u7F51\u9875\u7FFB\u8BD1\u5DF2\u5F00\u542F\uFF0C\u4F46\u6682\u65F6\u65E0\u6CD5\u7FFB\u8BD1\u5F53\u524D\u9875\u9762\u3002");
      }
      return;
    }
    try {
      const response = await send({ type: "page:restore" });
      if (!response?.ok && response?.error?.includes("chrome://")) {
        showMessage("\u81EA\u52A8\u7F51\u9875\u7FFB\u8BD1\u5DF2\u5173\u95ED\u3002");
        return;
      }
      renderResponse(response, "\u81EA\u52A8\u7F51\u9875\u7FFB\u8BD1\u5DF2\u5173\u95ED\u3002");
    } catch {
      showMessage("\u81EA\u52A8\u7F51\u9875\u7FFB\u8BD1\u5DF2\u5173\u95ED\u3002");
    }
  });
  for (const control of document.querySelectorAll(
    "select, input:not(#subtitleToggle):not(#autoTranslatePages)"
  )) {
    control.addEventListener("change", () => {
      if (!initialized) return;
      void saveSettings();
    });
  }
}
async function refreshStatus() {
  let response;
  try {
    response = await send({ type: "translator:status" });
  } catch {
    response = void 0;
  }
  if (!response || !response.ok) {
    subtitleToggle.checked = false;
    return;
  }
  subtitleToggle.checked = Boolean(response.running);
}
async function saveSettings() {
  await send({
    type: "translator:settings:set",
    settings: {
      targetLanguage: targetLanguageInput.value,
      mockWhenBackendMissing: false,
      autoTranslatePages: autoTranslatePagesInput.checked,
      selectionTranslationEnabled: selectionTranslationInput.checked,
      showOriginal: translationModeInput.value === "bilingual",
      showTranslation: true,
      subtitleStyle: subtitleStyleInput.value,
      asr: collectAsrSettings(),
      translation: collectTranslationSettings()
    }
  });
}
function renderSettings(settings) {
  const asr = settings.asr ?? DEFAULT_SETTINGS.asr;
  const translation = settings.translation ?? DEFAULT_SETTINGS.translation;
  targetLanguageInput.value = settings.targetLanguage ?? "zh-CN";
  autoTranslatePagesInput.checked = settings.autoTranslatePages ?? false;
  selectionTranslationInput.checked = settings.selectionTranslationEnabled ?? false;
  subtitleStyleInput.value = settings.subtitleStyle ?? "bold";
  translationModeInput.value = settings.showOriginal && settings.showTranslation ? "bilingual" : "translation";
  asrProviderInput.value = asr.provider;
  asrAppIdInput.value = asr.appId;
  asrAccessTokenInput.value = asr.accessToken;
  asrApiKeyInput.value = asr.apiKey;
  asrApiSecretInput.value = asr.apiSecret;
  asrSecretIdInput.value = asr.secretId;
  asrSecretKeyInput.value = asr.secretKey;
  asrAppKeyInput.value = asr.appKey;
  asrResourceIdInput.value = asr.resourceId;
  asrEndpointInput.value = asr.endpoint;
  asrModelInput.value = asr.model;
  applyAsrPreset(asr.provider, false);
  translationProviderInput.value = translation.provider;
  translationProtocolInput.value = translation.protocol;
  translationApiKeyInput.value = translation.apiKey;
  translationBaseUrlInput.value = translation.baseUrl;
  translationModelInput.value = translation.model;
  translationDisableThinkingInput.checked = translation.disableThinking;
  applyTranslationPreset(translation.provider, false);
}
function renderFallbackSettings() {
  targetLanguageInput.value = "zh-CN";
  autoTranslatePagesInput.checked = false;
  selectionTranslationInput.checked = false;
  subtitleStyleInput.value = "bold";
  translationModeInput.value = "translation";
  asrProviderInput.value = "volcengine";
  asrAppIdInput.value = "";
  asrAccessTokenInput.value = "";
  asrApiKeyInput.value = "";
  asrApiSecretInput.value = "";
  asrSecretIdInput.value = "";
  asrSecretKeyInput.value = "";
  asrAppKeyInput.value = "";
  asrResourceIdInput.value = "";
  asrEndpointInput.value = "";
  asrModelInput.value = "";
  applyAsrPreset("volcengine", true);
  translationProviderInput.value = "microsoft";
  translationProtocolInput.value = "openai";
  translationApiKeyInput.value = "";
  translationBaseUrlInput.value = "";
  translationModelInput.value = "";
  translationDisableThinkingInput.checked = true;
  applyTranslationPreset("microsoft", true);
}
function collectAsrSettings() {
  return {
    provider: asrProviderInput.value,
    appId: asrAppIdInput.value.trim(),
    accessToken: asrAccessTokenInput.value.trim(),
    apiKey: asrApiKeyInput.value.trim(),
    apiSecret: asrApiSecretInput.value.trim(),
    secretId: asrSecretIdInput.value.trim(),
    secretKey: asrSecretKeyInput.value.trim(),
    appKey: asrAppKeyInput.value.trim(),
    resourceId: asrResourceIdInput.value.trim(),
    endpoint: asrEndpointInput.value.trim(),
    model: asrModelInput.value.trim()
  };
}
function collectTranslationSettings() {
  return {
    provider: translationProviderInput.value,
    protocol: translationProtocolInput.value,
    apiKey: translationApiKeyInput.value.trim(),
    baseUrl: translationBaseUrlInput.value.trim(),
    model: translationModelInput.value.trim(),
    disableThinking: translationDisableThinkingInput.checked
  };
}
function applyAsrPreset(provider, forceDefaults) {
  const preset = ASR_PRESETS[provider] ?? ASR_PRESETS.volcengine;
  asrCredentialHint.textContent = preset.hint;
  setDatalistOptions(asrModelOptions, preset.models);
  setValueIfNeeded(asrEndpointInput, preset.defaults.endpoint, forceDefaults);
  setValueIfNeeded(asrModelInput, preset.defaults.model, forceDefaults);
  if (preset.defaults.resourceId) setValueIfNeeded(asrResourceIdInput, preset.defaults.resourceId, forceDefaults);
  for (const row of document.querySelectorAll("[data-asr-field]")) {
    const field = row.dataset.asrField;
    row.hidden = !field || !preset.fields.includes(field);
  }
}
function applyTranslationPreset(provider, forceDefaults) {
  const preset = TRANSLATION_PRESETS[provider] ?? TRANSLATION_PRESETS.microsoft;
  translationCredentialHint.textContent = preset.hint;
  setDatalistOptions(translationModelOptions, preset.models);
  if (forceDefaults) translationProtocolInput.value = preset.defaults.protocol;
  setValueIfNeeded(translationBaseUrlInput, getTranslationPresetBaseUrl(preset), forceDefaults);
  setValueIfNeeded(translationModelInput, preset.defaults.model, forceDefaults);
  const isMicrosoft = provider === "microsoft";
  for (const row of document.querySelectorAll("[data-translation-field]")) {
    row.hidden = isMicrosoft;
  }
}
function applyTranslationProtocolDefault() {
  const preset = TRANSLATION_PRESETS[translationProviderInput.value];
  if (!preset) return;
  const baseUrl = getTranslationPresetBaseUrl(preset);
  if (baseUrl) translationBaseUrlInput.value = baseUrl;
}
function getTranslationPresetBaseUrl(preset) {
  if (translationProtocolInput.value === "anthropic" && preset.anthropicBaseUrl) return preset.anthropicBaseUrl;
  return preset.defaults.baseUrl;
}
function setValueIfNeeded(input, value, force) {
  if (!value) return;
  if (force || !input.value.trim()) input.value = value;
}
function setDatalistOptions(datalist, values) {
  datalist.textContent = "";
  for (const value of values) {
    const option = document.createElement("option");
    option.value = value;
    datalist.append(option);
  }
}
function renderResponse(response, successMessage) {
  if (!response) {
    showMessage("\u8BF7\u6C42\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002");
    return;
  }
  if (response.ok) {
    showMessage(successMessage);
    return;
  }
  messageEl.textContent = response.error;
  messageEl.dataset.error = "true";
}
function showMessage(message) {
  messageEl.textContent = message;
  messageEl.dataset.error = "false";
}
function renderFallbackStatus() {
  subtitleToggle.checked = false;
}
async function send(message) {
  try {
    const response = await chrome.runtime.sendMessage(message);
    if (!response) {
      return { ok: false, error: "\u6269\u5C55\u540E\u53F0\u672A\u542F\u52A8\uFF0C\u8BF7\u5237\u65B0\u9875\u9762\u91CD\u8BD5\u3002" };
    }
    return response;
  } catch {
    return { ok: false, error: "\u6269\u5C55\u540E\u53F0\u672A\u542F\u52A8\uFF0C\u8BF7\u5237\u65B0\u9875\u9762\u91CD\u8BD5\u3002" };
  }
}
function getElement(id) {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Missing element #${id}`);
  return element;
}
//# sourceMappingURL=popup.js.map
